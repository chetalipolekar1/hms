<!DOCTYPE html>
<html>

<head>
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />


</head>

<body>


    <div>



        <?php

        include_once dirname(__FILE__) . './dbDetails.php';

        if (isset($_POST['hotelname'])) {                   //code to save room

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);  //create conncetion

            if ($conn->connect_error)                              //check connection
            {
                die("connection failed :" . $conn->connect_error);
            }
            if (isset($_FILES['image'])) {
                $file_name = $_FILES['image']['name'];
                $file_size = $_FILES['image']['size'];
                $file_tmp = $_FILES['image']['tmp_name'];
                $file_type = $_FILES['image']['type'];
                //$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
                $temp = explode(".", $_FILES["image"]["name"]);
                $newlogoname = round(microtime(true)) . '.' . end($temp);

                move_uploaded_file($file_tmp, "./images/" . $newlogoname);
            }
            $sql = "UPDATE hoteldetail SET DETAIL = '" . $_POST['hoteldetail'] . "', HOTEL_NAME ='" . $_POST['hotelname'] . "',ADDRESS='" . $_POST['hoteladdress'] . "',CONTACT='" . $_POST['hotelcontact'] . "',OTHER_CONTACT='" . $_POST['hotelothercontact'] . "',EMAIL='" . $_POST['hotelemail'] . "',HOTEL_LOGO='" . $newlogoname . "',WEBSITE='" . $_POST['hotelwebsite'] . "',REG_NO=" . $_POST['regno'] . ",FSREG_NO=" . $_POST['fsregno'] . " WHERE id=1";
            if ($_POST['image'] == '') {
                $sql = "UPDATE hoteldetail SET DETAIL = '" . $_POST['hoteldetail'] . "', HOTEL_NAME ='" . $_POST['hotelname'] . "',ADDRESS='" . $_POST['hoteladdress'] . "',CONTACT='" . $_POST['hotelcontact'] . "',OTHER_CONTACT='" . $_POST['hotelothercontact'] . "',EMAIL='" . $_POST['hotelemail'] . "',WEBSITE='" . $_POST['hotelwebsite'] . "',REG_NO=" . $_POST['regno'] . ",FSREG_NO=" . $_POST['fsregno'] . " WHERE id=1";
            }

            //insert value
            if ($conn->query($sql) === TRUE) {

                echo "Entry updated successfully";
            } else {
                echo "Error: " . "<br>" . $conn->error;
            }
            $conn->close();
        }

        include_once dirname(__FILE__) . './dbDetails.php';

        $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

        if ($conn->connect_error) {
            die("connection failed :" . $conn->connect_error);
        }
        $sql = "SELECT * FROM hoteldetail ";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $hotelName = $row['HOTEL_NAME'];

                $detail = $row['DETAIL'];
                $address = $row['ADDRESS'];
                $contact = $row['CONTACT'];
                $othercontact = $row['OTHER_CONTACT'];
                $address = $row['ADDRESS'];
                $email = $row['EMAIL'];
                $web = $row['WEBSITE'];
                $logo = $row['HOTEL_LOGO'];
                $regno = $row['REG_NO'];
                $fsregno = $row['FSREG_NO'];
            }
        }
        ?>
        <div>
            <div style="float:left;">
                <form action="./hoteldetail.php" method="POST" enctype="multipart/form-data">
                    <fieldset class="room">
                        <legend>Hotel Detail :</legend>
                        <div>
                            <div>

                                <input placeholder="Hotel Name" type="text" name="hotelname" value="<?php echo $hotelName; ?>" />
                            </div>
                            <div>
                                <input placeholder="hotel Detail(for bill print)" type="text" name="hoteldetail" value="<?php echo $detail; ?>" />
                            </div>
                            <div>

                                <input placeholder="Hotel Address" type="text" name="hoteladdress" value="<?php echo $address; ?>" />
                            </div>
                            <div>

                                <input placeholder="Hotel Contact" type="text" name="hotelcontact" value="<?php echo $contact; ?>" />
                            </div>
                            <div>

                                <input placeholder="Hotel Contact(Other)" type="text" name="hotelothercontact" value="<?php echo $othercontact; ?>" />
                            </div>
                            <div>

                                <input placeholder="Hotel E-mail" type="text" name="hotelemail" value="<?php echo $email; ?>" />
                            </div>
                            <div>

                                <input placeholder="Hotel Website" type="text" name="hotelwebsite" value="<?php echo $web; ?>" />
                            </div>
                            <div>

                                <input placeholder="Hotel Logo" type="file" name="image" id="image" value="<?php echo "<img src='./images/" . $logo . "'  height='100px' width='100px'/>"; ?>" />
                            </div>
                            <div>

                                <input placeholder="registration No." type="text" name="regno"  value="<?php echo $regno; ?>" />
                            </div>
                            <div>

                                <input placeholder="FS&S registration No." type="text" name="fsregno" value="<?php echo $fsregno; ?>" />
                            </div>
                            <div>
                                <input type="submit" class="btn1" value="save"></input>

                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>

    </div>
</body>

</html>