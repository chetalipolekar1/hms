<!DOCTYPE html>
<html>

<head>
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />

</head>

<body>
    <div>
        <?php

        include_once dirname(__FILE__) . './dbDetails.php';
        //Update
        if (isset($_POST['bookingid']) && $_POST['bookingid'] != '') {
            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);


            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "UPDATE booking_details SET GUEST_ID=" . $_POST['guestid'] . ", NAME='" . $_POST['username'] . "',SURNAME='" . $_POST['surname'] . "', ROOM_NO=" . $_POST['roomno'] . ", ROOM_TYPE ='" . $_POST['cool'] . "', NO_OF_DAYS=" . $_POST['day'] . ", NO_OF_MEMBERS=" . $_POST['member'] . ", BED='" . $_POST['bed'] . "', CHECK_IN='" . $_POST['checkin'] . "', CHECK_OUT='" . $_POST['checkout'] . "' WHERE BOOKING_ID = " . $_POST['bookingid'];

            //update value
            if ($conn->query($sql) === TRUE) {

                echo "Updated successfully";
            } else {
                echo "Error: "  . "<br>" . $conn->error;
            }
            $conn->close();
        } else if (isset($_POST['roomno'])) {                   //code to display bill



            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);
            if ($conn->error) {
                die("connection failed :" . $conn->error);
            }

            $sql = "INSERT INTO booking_details  (GUEST_ID,NAME,SURNAME,ROOM_NO, ROOM_TYPE, NO_OF_DAYS, NO_OF_MEMBERS,BED, CHECK_IN, CHECK_OUT) VALUES (" . $_POST['guestid'] . ", '" . $_POST['username'] . "','" . $_POST['surname'] . "'," . $_POST['roomno'] . ",'" . $_POST['cool'] . "'," . $_POST['day'] . "," . $_POST['member'] . ",'" . $_POST['bed'] . "','" . $_POST['checkin'] . "','" . $_POST['checkout'] . "')";

            if ($_POST['checkout'] == '' && $_POST['day'] == '') {
                $sql = "INSERT INTO booking_details  (GUEST_ID,NAME,SURNAME,ROOM_NO, ROOM_TYPE,  NO_OF_MEMBERS,BED, CHECK_IN) VALUES (" . $_POST['guestid'] . ", '" . $_POST['username'] . "','" . $_POST['surname'] . "'," . $_POST['roomno'] . ",'" . $_POST['cool'] . "'," . $_POST['member'] . ",'" . $_POST['bed'] . "','" . $_POST['checkin'] . "')";
            }


 

            if ($conn->query($sql) === TRUE) {
                echo " New Guest Detalis Entry successfully ";
            } else {
                echo " Error :" . "</br>" . $conn->error;
            }
            $conn->close();
        }

        //code to delete 
        if (isset($_GET['deletebookingid'])) {

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "DELETE FROM booking_details WHERE BOOKING_ID = " . $_GET['deletebookingid'];

            if ($conn->query($sql) === TRUE) {
                echo  " deleted succesfully.";
            } else {
                echo "Error deleting" . $conn->error;
            }
            $conn->close();
        }
        ?>


        <form action="./bookingdetail.php" method="POST">

            <fieldset>
                <legend>Booking Details :</legend>
                <div>
                    <div>
                        <input type="number" placeholder="Guest id" name="guestid" value="<?php if (isset($_GET['guestid'])) echo $_GET['guestid'] ?>" />
                    </div>
                    <input type="hidden" name="bookingid" value="<?php if (isset($_GET['bookingid'])) echo $_GET['bookingid'] ?>" />

                    <input type="text" name="username" placeholder="Name" maxlength="30" value="<?php if (isset($_GET['username'])) echo $_GET['username'] ?>" />
                    <div>

<input type="text" name="surname" placeholder="Surname" maxlength="30" value="<?php if (isset($_GET['surname'])) echo $_GET['surname'] ?>" />
</div>
<div>



<select name="roomno" value="<?php if (isset($_GET['roomno'])) echo $_GET['roomno'] ?>">

    <?php   
    if(isset($_GET['roomno']))       {                                                     // select from table
        echo   "<option>" . $_GET['roomno'] . "</option>";

         }else {
              include_once dirname(__FILE__) . './dbDetails.php';

    $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

    if ($conn->connect_error) {
        die("connection failed :" . $conn->connect_error);
    }
    $sql = "SELECT ROOM_NO FROM room where ROOM_NO not in ( SELECT booking_details.ROOM_NO from booking_details where booking_details.CHECK_OUT is NULL ) order by ROOM_NO";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            echo   "<option>" . $row['ROOM_NO'] . "</option>";
        }
    }
    $conn->close();
}
    ?>

</select>

</div>
                    <div>
                        Room Type :
                        <input type="radio" name="cool" value="AC" class="radio2" <?php if (isset($_GET['cool']) && $_GET['cool'] == 'AC') {
                                                                                        echo " checked";
                                                                                    }
                                                                                    ?> required/><label>AC</label>
                        <input type="radio" name="cool" value="Non-AC" class="radio2" <?php if (isset($_GET['cool']) && $_GET['cool'] == 'Non-AC') {
                                                                                            echo " checked";
                                                                                        }
                                                                                        ?> required/><label>Non-AC</label>
                    </div>

                    <div>

                        <input placeholder="No. of Member" type="number" name="member" value="<?php if (isset($_GET['member'])) echo $_GET['member'] ?>" />
                    </div>
                    <div>
                        NO. of Bed :
                        <input type="radio" name="bed" value="single" class="radio2" value="single" <?php if (isset($_GET['bed']) && ($_GET['bed']) == 'single') {
                                                                                            echo "checked";
                                                                                        } ?> required/><label>Single</label>
                        <input type="radio" name="bed" value="double" class="radio2" value="double" <?php if (isset($_GET['bed']) && ($_GET['bed']) == 'double') {
                                                                                                echo "checked";
                                                                                            } ?> required/><label>Double</label>
                    </div>


                    <div>
                        <div style="float:left;">
                            <label>Check-In</label>
                        </div>
                        <div style="float:right;width:81.5%;">

                            <input type="datetime-local" id="check" name="checkin" value="<?php date_default_timezone_set('Asia/Kolkata');

                                                                                            if (isset($_GET['checkin'])) {

                                                                                                echo date('Y-m-d\TH:i:s', strtotime($_GET['checkin']));
                                                                                            } else {
                                                                                                echo date('Y-m-d\TH:i:s');
                                                                                            }
                                                                                            ?>" />
                        </div>


                    </div>


                    <div>
                        <div style="float:left;">
                            <label>Check-Out</label>
                        </div>
                        <div style="float:right;width:81.5%;">

                            <input type="datetime-local" id="out" onchange="Noofdays()" name="checkout" value="<?php date_default_timezone_set('Asia/Kolkata');
                                                                                                                if (isset($_GET['checkout'])) {
                                                                                                                   
                                                                                                                    echo date('Y-m-d\TH:i:s');
                                                                                                                } 
                                                                                                                ?>" />
                        </div>

                        <div>

                            <input placeholder="No. Of Days" type="number" name="day" id="day" value="<?php if (isset($_GET['day'])) echo $_GET['day'] ?>" />
                        </div>




                        <div>
                            <input type="submit" class="btn1"></input>

                        </div>
                    </div>
            </fieldset>
        </form>
        <div style="float:center;">

            <table class="tbl">
                <tr>
                    <th>Booking id</th>
                    <th>Guest id</th>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>Room No.</th>
                    <th>Room Type</th>
                    <th>Stay Period</th>
                    <th>No. of members</th>
                    <th>bed</th>
                    <th>Check-in</th>
                    <th>Check-out</th>
                    <th>Active</th>
                </tr>
                <?php
                include_once dirname(__FILE__) . './dbDetails.php';
                $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                if ($conn->connect_error) {
                    die("connection failed :" . $conn->connect_error);
                }
                $sql = "SELECT * FROM booking_details ORDER BY BOOKING_ID  DESC";

                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {

                        echo "<tr><td>";

                        echo "<a class='actioicon' href='./billing.php?bookingid= " . $row['BOOKING_ID'] . "&username=" . $row['NAME'] . "&surname=" . $row['SURNAME'] . "&roomno=" . $row['ROOM_NO'] . "&day=" . $row['NO_OF_DAYS'] . "'>";
                        echo $row['BOOKING_ID'];
                        echo "</a>";
                        echo "</td>";
                        echo "<td>";
                        echo $row['GUEST_ID'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NAME'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['SURNAME'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['ROOM_NO'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['ROOM_TYPE'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NO_OF_DAYS'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NO_OF_MEMBERS'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['BED'];
                        echo "</td>";
                        echo "<td>";
                        $newDate = strtotime($row['CHECK_IN']);
                        echo date("d-m-y H:i:sa", $newDate);
                        echo "</td>";
                        echo "<td>";
                        $newDate = '';
                        if (!$row['CHECK_OUT'] == null || !$row['CHECK_OUT'] == '') {

                            $newDate = strtotime($row['CHECK_OUT']);
                            $newDate = date("d-m-y H:i:sa", $newDate);
                        }
                        echo $newDate;
                        echo "</td>";
                        echo "</td>";
                        echo "<td><span style='float: left;'><a class='onicon' href='./bookingdetail.php?bookingid=" . $row['BOOKING_ID'] . "&guestid=" . $row['GUEST_ID'] . "&username=" . $row['NAME'] . "&surname=" . $row['SURNAME'] . "&roomno=" . $row['ROOM_NO'] . "&day=" . $row['NO_OF_DAYS'] . "&member=" . $row['NO_OF_MEMBERS'] . "&cool=" . $row['ROOM_TYPE'] . "&bed=" . $row['BED'] . "&checkin=" . $row['CHECK_IN'] . "&checkout=" . $row['CHECK_OUT'] . "'>";
                        echo "<i class='fa fa-pencil-alt'></i></a></span>";
                        echo "<span style='float: right;'><a class='actionicon' href='./bookingdetail.php?deletebookingid=" . $row['BOOKING_ID'] . "'>";
                        echo "<i class='fa fa-trash-alt'></i></a></span>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo " Empty";
                }
                $conn->close();

                ?>
            </table>
        </div>
    </div>
    <script>
        function Noofdays() {
            new Date();
            
            var date1 = new Date(document.getElementById('check').value);
            date1.setHours(0);
            date1.setMinutes(0);
            date1.setSeconds(0);
            var noOfDay = document.getElementById('day');
            var date2 = new Date(document.getElementById('out').value);
            date2.setHours(24);
            date2.setMinutes(0);
            date2.setSeconds(0);
            var timeDiff = date2.getTime() - date1.getTime();
            var days = timeDiff / (1000 * 3600 * 24);
            noOfDay.value = parseInt(days, 10);
        }

        window.onload = Noofdays();
    </script>
</body>


</html>