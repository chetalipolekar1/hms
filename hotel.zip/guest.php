<!DOCTYPE html>
<html>

<head>
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />

    <script type="text/javascript">
        function showCForm() {
            var selectedCountry = document.getElementById('country').value;

            if (selectedCountry.toUpperCase() != 'INDIA') {
                document.getElementById('cform').style.display = 'block';
            } else {
                document.getElementById('cform').style.display = 'none';
            }
        }
    </script>
    <script type="text/javascript">
        function ageCount() {
            var today = new Date();
            var date1 = document.getElementById("dob").value;
            var dob = new Date(date1);
            var month = dob.getMonth();
            var day = dob.getDate();
            var age = today.getFullYear() - dob.getFullYear();
            if (today.getMonth() < month || (today.getMonth() == month && today.getDate() < day)) {
                age--;
            }
            if (age < 0) {
                alert("Invalid Date of Birth");
                return false;
            } else {
                document.getElementById("age").value = age;
                doucment.getElementById("age").focus();
                alert(age);
                return true;
            }
        }
    </script>
</head>

<body>
    <div>
        <?php

        include_once dirname(__FILE__) . './dbDetails.php';

        if (isset($_POST['guestid']) && $_POST['guestid'] != '') {
            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);
            if ($conn->connect_error) {
                die("connection error :" . $conn->connect_error);
            }
            $sql = "UPDATE guest_details  SET  NAME='" . $_POST['username'] . "',SURNAME='" . $_POST['surname'] . "',AGE=" . $_POST['age'] . ",DOB='" . $_POST['DOB'] . "',ADDRESS='" . $_POST['address'] . "',PINCODE=" . $_POST['pincode'] . ",STATE='" . $_POST['states'] . "',COUNTRY='" . $_POST['country'] . "',NATIONALITY='" . $_POST['nationality'] . "',SPECIAL_CATEGORY='" . $_POST['category'] . "',CONTACT_NO=" . $_POST['phone'] . ",EMAIL='" . $_POST['email'] . "',GENDER='" . $_POST['gender'] . "',MARITAL_STATUS='" . $_POST['marital'] . "',ID_PROOF='" . $_POST['idproof'] . "',ID_PROOF_NO='" . $_POST['number'] . "',NATIONALITY='" . $_POST['nationality'] . "',FROMCITY='" . $_POST['fromcity'] . "',TOCITY='" . $_POST['tocity'] . "',TRAVELMEDIUM='" . $_POST['travelmedium'] . "',TRAVELNO='" . $_POST['travelno'] . "' WHERE GUEST_ID = " . $_POST['guestid'];
            if ($conn->query($sql) === TRUE) {
                echo "updated succesfully";
            } else {
                echo "error " .  "</br>" . $conn->error;
            }
            $conn->close();
        } else if (isset($_POST['username'])) {
            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);
            if ($conn->error) {
                die("connection failed :" . $conn->error);
            }

            //code to insert image
            if (isset($_FILES['image'])) {
                $errors = array();
                $file_name = $_FILES['image']['name'];
                $file_size = $_FILES['image']['size'];
                $file_tmp = $_FILES['image']['tmp_name'];
                $file_type = $_FILES['image']['type'];
                //$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
                $temp = explode(".", $_FILES["image"]["name"]);
                $newfilename = round(microtime(true)) . '.' . end($temp);

                if ($file_size > 2097152) {
                    $errors[] = 'File size must be less than 2 MB';
                    echo "file size greater";
                } else {
                    move_uploaded_file($file_tmp, "./images/" . $newfilename);

                    $idproofImage = "";
                    if(isset($_FILES['idimage'])){
                        $file_name = $_FILES['idimage']['name'];
                        $file_size = $_FILES['idimage']['size'];
                        $file_tmp = $_FILES['idimage']['tmp_name'];
                        $file_type = $_FILES['idimage']['type'];
                        //$file_ext=strtolower(end(explode('.',$_FILES['idimage']['name'])));
                        $temp = explode(".", $_FILES["idimage"]["name"]);
                        $idproofImage = round(microtime(true)) . '.' . end($temp);
        
                        if ($file_size > 40960) {
                            $errors[] = 'File size must be less than 40kb';
                            echo "id proof file size greater";
                        } else {
                            move_uploaded_file($file_tmp, "./images/" .$idproofImage );
                        }        
                    }
                    $sql = "INSERT INTO guest_details (`IMAGE`,`ID_IMAGE`,`NAME`,`SURNAME`, `GENDER`, `AGE`,`DOB`, `ADDRESS`, `PINCODE`, `STATE`, `COUNTRY`,`NATIONALITY`,`SPECIAL_CATEGORY`, `CONTACT_NO`, `EMAIL`, `MARITAL_STATUS`, `ID_PROOF`, `ID_PROOF_NO`, `FROMCITY`, `TOCITY`, `TRAVELMEDIUM`, `TRAVELNO`, `VISIT_PURPOSE`) VALUES ( '" . $newfilename . "','" .$idproofImage  . "', '" . $_POST['username'] . "','" . $_POST['surname'] . "','" . $_POST['gender'] . "'," . $_POST['age'] . ",'" . $_POST['DOB'] . "','" . $_POST['address'] . "'," . $_POST['pincode'] . ",'" . $_POST['states'] . "','" . strtoupper($_POST['country']) . "','" . $_POST['nationality'] . "','" . $_POST['category'] . "'," . $_POST['phone'] . ",'" . $_POST['email'] . "','" . $_POST['marital'] . "','" . $_POST['idproof'] . "','" . $_POST['number'] . "','" . $_POST['fromcity'] . "','" . $_POST['tocity'] . "','" . $_POST['travelmedium'] . "','" . $_POST['travelno'] . "','" . $_POST['visit'] . "')";
                    if ($_POST['DOB'] == '' && $_POST['age'] == '') {
                        $sql = "INSERT INTO guest_details (`IMAGE`,`ID_IMAGE`, `NAME`,`SURNAME`, `GENDER`, `ADDRESS`, `PINCODE`, `STATE`, `COUNTRY`,`NATIONALITY`,`SPECIAL_CATEGORY`, `CONTACT_NO`, `EMAIL`, `MARITAL_STATUS`, `ID_PROOF`, `ID_PROOF_NO`, `FROMCITY`, `TOCITY`, `TRAVELMEDIUM`, `TRAVELNO`, `VISIT_PURPOSE`) VALUES ( '" . $newfilename . "','" . $idproofImage . "', '" . $_POST['username'] . "','" . $_POST['surname'] . "','" . $_POST['gender'] . "','" . $_POST['address'] . "'," . $_POST['pincode'] . ",'" . $_POST['states'] . "','" . strtoupper($_POST['country']) . "','" . $_POST['nationality'] . "','" . $_POST['category'] . "'," . $_POST['phone'] . ",'" . $_POST['email'] . "','" . $_POST['marital'] . "','" . $_POST['idproof'] . "','" . $_POST['number'] . "','" . $_POST['fromcity'] . "','" . $_POST['tocity'] . "','" . $_POST['travelmedium'] . "','" . $_POST['travelno'] . "','" . $_POST['visit'] . "')";
                    }
                   
                    if ($conn->query($sql) === TRUE) {
                        echo " New Guest Detalis Entry added successfully ";
                    } else {
                        echo " Error :"  . "</br>" . $conn->error;
                    }
                    //return the last inserted autoincreamented id
                    $guestID = mysqli_insert_id($conn);
                    $conn->close();
                    if (isset($_POST['passport']) && $_POST['passport'] != '') {
                        $conn = new mysqli(dbhost, dbusername, dbpass, dbName);
                        if ($conn->error) {
                            die("connection failed :" . $conn->error);
                        }

                        $sql = "INSERT INTO cform (`GUEST_ID`,`CITY`, `PASSPORT_NO`, `PASS_CITY`, `PASS_COUNTRY`, `PASS_DATE`, `VALID_DATE`,
             `VISA`, `VISA_CITY`, `VISA_COUNTRY`, `VISA_DATE`, `VISA_VALID_DATE`, `VISA_TYPE`, `VISA_SUBTYPE`, 
             `ARRIVE_COUNTRY`, `ARRIVE_CITY`, `DATE_ARRIVE_INDIA`, `DATE_ARRIVE_HOTEL`, `TIME_IN_HOTEL`, `EMPLOYED_IN_INDIA`, `NEXT_DEST`, `DEST_STATE`, `DEST_CITY`, `DEST_PLACE`, `CONTACT_INDIA`, `MOBILE_INDIA`, `CONTACT_COUNTRY`, `MOBILE_COUNTRY`, `REMARK`) VALUES ( " .
                            $guestID . ",'" . $_POST['countrycity'] . "',  '" . $_POST['passport'] . "',  '" . $_POST['passcity'] . "', '" . $_POST['passcountry'] . "', '" . $_POST['passdate'] . "', '" . $_POST['validdate'] . "',  
            '" . $_POST['visa'] . "', '" . $_POST['visacity'] . "', '" . $_POST['visacountry'] . "',  '" . $_POST['visadate'] . "', '" . $_POST['visavaliddate'] . "', '" . $_POST['typeofvisa'] . "', '" . $_POST['subtype'] . "',  '" . $_POST['arrivecountry'] . "', '" . $_POST['arrivecity'] . "', '" . $_POST['arrivedate'] . "', '" . $_POST['inhotel'] . "', '" . $_POST['hoteltime'] . "', '" . $_POST['select'] . "', '"
                            .  $_POST['destination'] . "', '" . $_POST['visitstate'] . "', '" . $_POST['visitcity'] . "', '" . $_POST['visitplace'] . "', "
                            . $_POST['contactindia'] . ", " . $_POST['mobileindia'] . ", " . $_POST['contactcountry'] . ", " . $_POST['mobilecountry'] . ", '" . $_POST['remark'] . "')";

                        if ($conn->query($sql) === TRUE) {
                            echo " C Form Entry added successfully ";
                        } else {
                            echo " Error :" . "</br>" . $conn->error;
                        }
                        $conn->close();
                    }
                }
            }
        }
        if (isset($_GET['deleteguestid'])) {

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "DELETE FROM guest_details WHERE GUEST_ID = " . $_GET['deleteguestid'];

            if ($conn->query($sql) === TRUE) {
                echo  " deleted succesfully.";
            } else {
                echo "Error deleting name" . $conn->error;
            }
            $conn->close();
        }
        ?>

        <div>
            <form action="./guest.php" method="POST" enctype="multipart/form-data">

                <fieldset>

                    <legend>Guest Details :</legend>

                    <div>
                        <div>
                            <input type="file" name="image" />
                        </div>
                       
                        <div>
                            <input type="hidden" name="guestid" value="<?php if (isset($_GET['guestid'])) echo $_GET['guestid'] ?>" />
                            <input type="text" id="uname" name="username" placeholder="Name" maxlength="30" value="<?php if (isset($_GET['username'])) echo $_GET['username'] ?>" />
                        </div>
                        <div>

                            <input type="text" name="surname" placeholder="Surname" maxlength="30" value="<?php if (isset($_GET['surname'])) echo $_GET['surname'] ?>" />
                        </div>
                        <div>
                            <input type="radio" name="gender" class="radio2" value="MALE" <?php if (isset($_GET['gender']) && ($_GET['gender']) == 'MALE') {
                                                                                                echo "checked";
                                                                                            } ?> />Male
                            <input type="radio" name="gender" class="radio2" value="FEMALE" <?php if (isset($_GET['gender']) && ($_GET['gender']) == 'FEMALE') {
                                                                                                echo "checked";
                                                                                            } ?> />Female
                            <input type="radio" name="gender" class="radio2" value="TRANSGENDER" <?php if (isset($_GET['gender']) && ($_GET['gender']) == 'TRANSGENDER') {
                                                                                                        echo "checked";
                                                                                                    } ?> />transgender
                        </div>
                        <div>
                            <div style="float:left;">
                                <label>DOB :</label>
                            </div>
                            <div style="float:right;width:89%;">
                                <input type="date" id="dob" onchange="ageCount()" name="DOB" value="<?php

                                                                                                    if (isset($_GET['DOB'])) {
                                                                                                        echo date('Y-m-d', strtotime($_GET['DOB']));
                                                                                                    } 
                                                                                                    ?>" />
                            </div>
                        </div>
                        <div>

                            <input type="number" name="age" id="age" placeholder="Age" min="0" max="150" value="<?php if (isset($_GET['age'])) echo $_GET['age'] ?>" />
                        </div>

                        <div>

                            <input type="text" name="address" placeholder="Address" value="<?php if (isset($_GET['address'])) echo $_GET['address'] ?>" />
                        </div>
                        <div>

                            <input type="text" name="pincode" placeholder="Pincode" value="<?php if (isset($_GET['pincode'])) echo $_GET['pincode'] ?>" />
                        </div>
                        <div>

                            <input type="text" list="states" name="states" placeholder="States" value="<?php if (isset($_GET['states'])) echo $_GET['states'] ?>" />
                            <datalist id="states">
                                <option value="Andhra Pradesh">Andhra Pradesh</option>
                                <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                <option value="Assam">Assam</option>
                                <option value="Bihar">Bihar</option>
                                <option value="Chandigarh">Chandigarh</option>
                                <option value="Chhattisgarh">Chhattisgarh</option>
                                <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                <option value="Daman and Diu">Daman and Diu</option>
                                <option value="Delhi">Delhi</option>
                                <option value="Lakshadweep">Lakshadweep</option>
                                <option value="Puducherry">Puducherry</option>
                                <option value="Goa">Goa</option>
                                <option value="Gujarat">Gujarat</option>
                                <option value="Haryana">Haryana</option>
                                <option value="Himachal Pradesh">Himachal Pradesh</option>
                                <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                <option value="Jharkhand">Jharkhand</option>
                                <option value="Karnataka">Karnataka</option>
                                <option value="Kerala">Kerala</option>
                                <option value="Madhya Pradesh">Madhya Pradesh</option>
                                <option value="Maharashtra">Maharashtra</option>
                                <option value="Manipur">Manipur</option>
                                <option value="Meghalaya">Meghalaya</option>
                                <option value="Mizoram">Mizoram</option>
                                <option value="Nagaland">Nagaland</option>
                                <option value="Odisha">Odisha</option>
                                <option value="Punjab">Punjab</option>
                                <option value="Rajasthan">Rajasthan</option>
                                <option value="Sikkim">Sikkim</option>
                                <option value="Tamil Nadu">Tamil Nadu</option>
                                <option value="Telangana">Telangana</option>
                                <option value="Tripura">Tripura</option>
                                <option value="Uttar Pradesh">Uttar Pradesh</option>
                                <option value="Uttarakhand">Uttarakhand</option>
                                <option value="West Bengal">West Bengal</option>
                            </datalist>
                        </div>
                        <div>

                            <input type="text" list="countryList" id="country" onchange="showCForm()" name="country" placeholder="Country" value="<?php if (isset($_GET['country'])) echo $_GET['country'] ?>" />
                            <datalist id="countryList">
                                <option value="Afganistan">Afghanistan</option>
                                <option value="Albania">Albania</option>
                                <option value="Algeria">Algeria</option>
                                <option value="American Samoa">American Samoa</option>
                                <option value="Andorra">Andorra</option>
                                <option value="Angola">Angola</option>
                                <option value="Anguilla">Anguilla</option>
                                <option value="Antigua & Barbuda">Antigua & Barbuda</option>
                                <option value="Argentina">Argentina</option>
                                <option value="Armenia">Armenia</option>
                                <option value="Aruba">Aruba</option>
                                <option value="Australia">Australia</option>
                                <option value="Austria">Austria</option>
                                <option value="Azerbaijan">Azerbaijan</option>
                                <option value="Bahamas">Bahamas</option>
                                <option value="Bahrain">Bahrain</option>
                                <option value="Bangladesh">Bangladesh</option>
                                <option value="Barbados">Barbados</option>
                                <option value="Belarus">Belarus</option>
                                <option value="Belgium">Belgium</option>
                                <option value="Belize">Belize</option>
                                <option value="Benin">Benin</option>
                                <option value="Bermuda">Bermuda</option>
                                <option value="Bhutan">Bhutan</option>
                                <option value="Bolivia">Bolivia</option>
                                <option value="Bonaire">Bonaire</option>
                                <option value="Bosnia & Herzegovina">Bosnia & Herzegovina</option>
                                <option value="Botswana">Botswana</option>
                                <option value="Brazil">Brazil</option>
                                <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                                <option value="Brunei">Brunei</option>
                                <option value="Bulgaria">Bulgaria</option>
                                <option value="Burkina Faso">Burkina Faso</option>
                                <option value="Burundi">Burundi</option>
                                <option value="Cambodia">Cambodia</option>
                                <option value="Cameroon">Cameroon</option>
                                <option value="Canada">Canada</option>
                                <option value="Canary Islands">Canary Islands</option>
                                <option value="Cape Verde">Cape Verde</option>
                                <option value="Cayman Islands">Cayman Islands</option>
                                <option value="Central African Republic">Central African Republic</option>
                                <option value="Chad">Chad</option>
                                <option value="Channel Islands">Channel Islands</option>
                                <option value="Chile">Chile</option>
                                <option value="China">China</option>
                                <option value="Christmas Island">Christmas Island</option>
                                <option value="Cocos Island">Cocos Island</option>
                                <option value="Colombia">Colombia</option>
                                <option value="Comoros">Comoros</option>
                                <option value="Congo">Congo</option>
                                <option value="Cook Islands">Cook Islands</option>
                                <option value="Costa Rica">Costa Rica</option>
                                <option value="Cote DIvoire">Cote DIvoire</option>
                                <option value="Croatia">Croatia</option>
                                <option value="Cuba">Cuba</option>
                                <option value="Curaco">Curacao</option>
                                <option value="Cyprus">Cyprus</option>
                                <option value="Czech Republic">Czech Republic</option>
                                <option value="Denmark">Denmark</option>
                                <option value="Djibouti">Djibouti</option>
                                <option value="Dominica">Dominica</option>
                                <option value="Dominican Republic">Dominican Republic</option>
                                <option value="East Timor">East Timor</option>
                                <option value="Ecuador">Ecuador</option>
                                <option value="Egypt">Egypt</option>
                                <option value="El Salvador">El Salvador</option>
                                <option value="Equatorial Guinea">Equatorial Guinea</option>
                                <option value="Eritrea">Eritrea</option>
                                <option value="Estonia">Estonia</option>
                                <option value="Ethiopia">Ethiopia</option>
                                <option value="Falkland Islands">Falkland Islands</option>
                                <option value="Faroe Islands">Faroe Islands</option>
                                <option value="Fiji">Fiji</option>
                                <option value="Finland">Finland</option>
                                <option value="France">France</option>
                                <option value="French Guiana">French Guiana</option>
                                <option value="French Polynesia">French Polynesia</option>
                                <option value="French Southern Ter">French Southern Ter</option>
                                <option value="Gabon">Gabon</option>
                                <option value="Gambia">Gambia</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Germany">Germany</option>
                                <option value="Ghana">Ghana</option>
                                <option value="Gibraltar">Gibraltar</option>
                                <option value="Great Britain">Great Britain</option>
                                <option value="Greece">Greece</option>
                                <option value="Greenland">Greenland</option>
                                <option value="Grenada">Grenada</option>
                                <option value="Guadeloupe">Guadeloupe</option>
                                <option value="Guam">Guam</option>
                                <option value="Guatemala">Guatemala</option>
                                <option value="Guinea">Guinea</option>
                                <option value="Guyana">Guyana</option>
                                <option value="Haiti">Haiti</option>
                                <option value="Hawaii">Hawaii</option>
                                <option value="Honduras">Honduras</option>
                                <option value="Hong Kong">Hong Kong</option>
                                <option value="Hungary">Hungary</option>
                                <option value="Iceland">Iceland</option>
                                <option value="Indonesia">Indonesia</option>
                                <option value="India">India</option>
                                <option value="Iran">Iran</option>
                                <option value="Iraq">Iraq</option>
                                <option value="Ireland">Ireland</option>
                                <option value="Isle of Man">Isle of Man</option>
                                <option value="Israel">Israel</option>
                                <option value="Italy">Italy</option>
                                <option value="Jamaica">Jamaica</option>
                                <option value="Japan">Japan</option>
                                <option value="Jordan">Jordan</option>
                                <option value="Kazakhstan">Kazakhstan</option>
                                <option value="Kenya">Kenya</option>
                                <option value="Kiribati">Kiribati</option>
                                <option value="Korea North">Korea North</option>
                                <option value="Korea Sout">Korea South</option>
                                <option value="Kuwait">Kuwait</option>
                                <option value="Kyrgyzstan">Kyrgyzstan</option>
                                <option value="Laos">Laos</option>
                                <option value="Latvia">Latvia</option>
                                <option value="Lebanon">Lebanon</option>
                                <option value="Lesotho">Lesotho</option>
                                <option value="Liberia">Liberia</option>
                                <option value="Libya">Libya</option>
                                <option value="Liechtenstein">Liechtenstein</option>
                                <option value="Lithuania">Lithuania</option>
                                <option value="Luxembourg">Luxembourg</option>
                                <option value="Macau">Macau</option>
                                <option value="Macedonia">Macedonia</option>
                                <option value="Madagascar">Madagascar</option>
                                <option value="Malaysia">Malaysia</option>
                                <option value="Malawi">Malawi</option>
                                <option value="Maldives">Maldives</option>
                                <option value="Mali">Mali</option>
                                <option value="Malta">Malta</option>
                                <option value="Marshall Islands">Marshall Islands</option>
                                <option value="Martinique">Martinique</option>
                                <option value="Mauritania">Mauritania</option>
                                <option value="Mauritius">Mauritius</option>
                                <option value="Mayotte">Mayotte</option>
                                <option value="Mexico">Mexico</option>
                                <option value="Midway Islands">Midway Islands</option>
                                <option value="Moldova">Moldova</option>
                                <option value="Monaco">Monaco</option>
                                <option value="Mongolia">Mongolia</option>
                                <option value="Montserrat">Montserrat</option>
                                <option value="Morocco">Morocco</option>
                                <option value="Mozambique">Mozambique</option>
                                <option value="Myanmar">Myanmar</option>
                                <option value="Nambia">Nambia</option>
                                <option value="Nauru">Nauru</option>
                                <option value="Nepal">Nepal</option>
                                <option value="Netherland Antilles">Netherland Antilles</option>
                                <option value="Netherlands">Netherlands (Holland, Europe)</option>
                                <option value="Nevis">Nevis</option>
                                <option value="New Caledonia">New Caledonia</option>
                                <option value="New Zealand">New Zealand</option>
                                <option value="Nicaragua">Nicaragua</option>
                                <option value="Niger">Niger</option>
                                <option value="Nigeria">Nigeria</option>
                                <option value="Niue">Niue</option>
                                <option value="Norfolk Island">Norfolk Island</option>
                                <option value="Norway">Norway</option>
                                <option value="Oman">Oman</option>
                                <option value="Pakistan">Pakistan</option>
                                <option value="Palau Island">Palau Island</option>
                                <option value="Palestine">Palestine</option>
                                <option value="Panama">Panama</option>
                                <option value="Papua New Guinea">Papua New Guinea</option>
                                <option value="Paraguay">Paraguay</option>
                                <option value="Peru">Peru</option>
                                <option value="Phillipines">Philippines</option>
                                <option value="Pitcairn Island">Pitcairn Island</option>
                                <option value="Poland">Poland</option>
                                <option value="Portugal">Portugal</option>
                                <option value="Puerto Rico">Puerto Rico</option>
                                <option value="Qatar">Qatar</option>
                                <option value="Republic of Montenegro">Republic of Montenegro</option>
                                <option value="Republic of Serbia">Republic of Serbia</option>
                                <option value="Reunion">Reunion</option>
                                <option value="Romania">Romania</option>
                                <option value="Russia">Russia</option>
                                <option value="Rwanda">Rwanda</option>
                                <option value="St Barthelemy">St Barthelemy</option>
                                <option value="St Eustatius">St Eustatius</option>
                                <option value="St Helena">St Helena</option>
                                <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                                <option value="St Lucia">St Lucia</option>
                                <option value="St Maarten">St Maarten</option>
                                <option value="St Pierre & Miquelon">St Pierre & Miquelon</option>
                                <option value="St Vincent & Grenadines">St Vincent & Grenadines</option>
                                <option value="Saipan">Saipan</option>
                                <option value="Samoa">Samoa</option>
                                <option value="Samoa American">Samoa American</option>
                                <option value="San Marino">San Marino</option>
                                <option value="Sao Tome & Principe">Sao Tome & Principe</option>
                                <option value="Saudi Arabia">Saudi Arabia</option>
                                <option value="Senegal">Senegal</option>
                                <option value="Seychelles">Seychelles</option>
                                <option value="Sierra Leone">Sierra Leone</option>
                                <option value="Singapore">Singapore</option>
                                <option value="Slovakia">Slovakia</option>
                                <option value="Slovenia">Slovenia</option>
                                <option value="Solomon Islands">Solomon Islands</option>
                                <option value="Somalia">Somalia</option>
                                <option value="South Africa">South Africa</option>
                                <option value="Spain">Spain</option>
                                <option value="Sri Lanka">Sri Lanka</option>
                                <option value="Sudan">Sudan</option>
                                <option value="Suriname">Suriname</option>
                                <option value="Swaziland">Swaziland</option>
                                <option value="Sweden">Sweden</option>
                                <option value="Switzerland">Switzerland</option>
                                <option value="Syria">Syria</option>
                                <option value="Tahiti">Tahiti</option>
                                <option value="Taiwan">Taiwan</option>
                                <option value="Tajikistan">Tajikistan</option>
                                <option value="Tanzania">Tanzania</option>
                                <option value="Thailand">Thailand</option>
                                <option value="Togo">Togo</option>
                                <option value="Tokelau">Tokelau</option>
                                <option value="Tonga">Tonga</option>
                                <option value="Trinidad & Tobago">Trinidad & Tobago</option>
                                <option value="Tunisia">Tunisia</option>
                                <option value="Turkey">Turkey</option>
                                <option value="Turkmenistan">Turkmenistan</option>
                                <option value="Turks & Caicos Is">Turks & Caicos Is</option>
                                <option value="Tuvalu">Tuvalu</option>
                                <option value="Uganda">Uganda</option>
                                <option value="United Kingdom">United Kingdom</option>
                                <option value="Ukraine">Ukraine</option>
                                <option value="United Arab Erimates">United Arab Emirates</option>
                                <option value="United States of America">United States of America</option>
                                <option value="Uraguay">Uruguay</option>
                                <option value="Uzbekistan">Uzbekistan</option>
                                <option value="Vanuatu">Vanuatu</option>
                                <option value="Vatican City State">Vatican City State</option>
                                <option value="Venezuela">Venezuela</option>
                                <option value="Vietnam">Vietnam</option>
                                <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                                <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                                <option value="Wake Island">Wake Island</option>
                                <option value="Wallis & Futana Is">Wallis & Futana Is</option>
                                <option value="Yemen">Yemen</option>
                                <option value="Zaire">Zaire</option>
                                <option value="Zambia">Zambia</option>
                                <option value="Zimbabwe">Zimbabwe</option>
                            </datalist>
                        </div>

                        <!-- CFORM
                            -->

                        <div id="cform" style="display: none">

                            <form action="" method="POST">
                                <div>
                                    <label style="color: blue; font-weight: bold;">If Resident of another Country Please give some following Details :
                                    </label>
                                </div>
                                <fieldset>
                                    <legend>C-Form</legend>
                                    <div>

                                        <div>
                                            <h4>Address in Country where residing permanently :</h4>
                                            <div>
                                                <input type="text" name="countrycity" placeholder="city" />
                                            </div>
                                        </div>
                                        <div>
                                            <h4>Passport detail :</h4>
                                            <div>
                                                <input type="text" name="passport" placeholder="Passport No." />
                                            </div>
                                            <div>
                                                <label>place of issue</label>
                                                <div>
                                                    <input type="text" name="passcity" placeholder="City" />
                                                </div>
                                                <div>
                                                    <input type="text" list="countryList" name="passcountry" placeholder="Country" />

                                                </div>
                                            </div>
                                            <div>
                                                <label>Date of issue</label>
                                                <div>
                                                    <input type="date" name="passdate" />
                                                </div>
                                                <label>Valid till</label>
                                                <div>
                                                    <input type="date" name="validdate" />
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <h4>Visa Details :</h4>
                                            <div>
                                                <input type="text" name="visa" placeholder="Visa No." />
                                            </div>
                                            <div>
                                                <label>place of issue</label>
                                                <div>
                                                    <input type="text" name="visacity" placeholder="City" />
                                                </div>
                                                <div>
                                                    <input type="text" list="countryList" name="visacountry" placeholder="Country" />

                                                </div>
                                            </div>
                                            <div>
                                                <label>Date of issue</label>
                                                <div>
                                                    <input type="date" name="visadate" />
                                                </div>
                                                <label>Valid till</label>
                                                <div>
                                                    <input type="date" name="visavaliddate" />
                                                </div>
                                                <label>Type of Visa</label>
                                                <div>
                                                    <input type="text" list="type" name="typeofvisa" placeholder="Type of Visa" />
                                                    <datalist id="type">
                                                        <option value="BUSINESS VISA">BUSINESS VISA</option>
                                                        <option value="CONFERENCE VISA">CONFERENCE VISA</option>
                                                        <option value="DIPLOMATIC DEPENDENT VISA">DIPLOMATIC DEPENDENT VISA</option>
                                                        <option value="DIPLOMATIC VISA">DIPLOMATIC VISA</option>
                                                        <option value="DOUBLE ENTRY VISA">DOUBLE ENTRY VISA(ONLY FOR BANGLADESH NATIONALS)
                                                        </option>
                                                        <option value="EMPLOYEMENT VISA">EMPLOYEMENT VISA</option>
                                                        <option value="ENTRY VISA">ENTRY VISA</option>
                                                        <option value="e-VISA">e-VISA</option>
                                                        <option value="FILMS VISA">FILMS VISA</option>
                                                        <option value="JOURNALIST VISA">JOURNALIST VISA</option>
                                                        <option value="LONG TERM VISA">LONG TERM VISA</option>
                                                        <option value="MEDICAL">MEDICAL</option>
                                                        <option value="MISC SP PERMISSION">MISC SP PERMISSION</option>
                                                        <option value="MISSIONARY VISA">MISSIONARY VISA</option>
                                                        <option value="MOUNTAINEERING VISA">MOUNTAINEERING VISA</option>
                                                        <option value="OCI">OCI</option>
                                                        <option value="OFFICIAL DEPENDENT VISA">OFFICIAL DEPENDENT VISA</option>
                                                        <option value="OFFICIAL VISA">OFFICIAL VISA</option>
                                                        <option value="POI CARD HOLDER">POI CARD HOLDER</option>
                                                        <option value="PLIGRIM VISA">PLIGRIM VISA(ONLY FOR PAKISTAN NATIONALS)</option>
                                                        <option value="STUDENT VISA">STUDENT VISA</option>
                                                        <option value="TEMPORARY LANDING PERMIT">TEMPORARY LANDING PERMIT</option>
                                                        <option value="TOURIST VISA">TOURIST VISA</option>
                                                        <option value="TRANSIT VISA">TRANSIT VISA</option>
                                                        <option value="UN DIPLOMAT VISA">UN DIPLOMAT VISA</option>
                                                        <option value="UNITED NATION">UNITED NATION</option>
                                                        <option value="UN OFFICIAL VISA">UN OFFICIAL VISA</option>
                                                        <option value="VISA-ON-ARRIVAL">VISA-ON-ARRIVAL</option>
                                                        <option value="VISITOR VISA">VISITOR VISA(ONLY FOR PAKISTAN NATIONALS)</option>

                                                    </datalist>
                                                </div>
                                                <div>
                                                    <label>VISA SUB TYPE</label>
                                                    <input type="text" name="subtype" placeholder="VISA SUB TYPE" />
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <h4>Arrival Information :</h4>
                                            <div>
                                                <input type="text" list="countryList" name="arrivecountry" placeholder="arrived from country" />

                                            </div>
                                            <div>
                                                <input type="text" name="arrivecity" placeholder="arrived from city" />
                                            </div>
                                            <div>
                                                <label>date of arrival in india</label>
                                                <input type="date" name="arrivedate" />
                                            </div>
                                            <div>
                                                <label>date of arrival in hotel</label>
                                                <input type="date" name="inhotel" value="<?php

                                                                                            if (isset($_GET['inhotel'])) {

                                                                                                echo date('Y-m-d', strtotime($_GET['inhotel']));
                                                                                            } else {
                                                                                                echo date('Y-m-d');
                                                                                            }
                                                                                            ?>" />
                                            </div>
                                            <div>
                                                <label>time of arrival in hotel</label>
                                                <input type="time" name="hoteltime" value="<?php date_default_timezone_set('Asia/Kolkata');
                                                                                            echo date('H:i');
                                                                                            ?>" />
                                            </div>

                                        </div>
                                        <div>
                                            <h4>Other Details :</h4>
                                            <div>
                                                <label>whether employed in india</label>
                                                <input type="radio" class="radio2" name="select" value="Yes" /><label>Yes</label>
                                                <input type="radio" class="radio2" name="select" value="No" /><label>No</label>
                                            </div>
                                          
                                            <div>
                                                <label>Next


                                                </label>
                                                <input type="radio" class="radio2" name="destination" value="inside india" /><label> inside india</label>
                                                <input type="radio" class="radio2" name="destination" value="outside india" /><label> outside india</label>
                                            </div>
                                            <div>
                                                <input type="text" name="visitstate" placeholder="state" />
                                            </div>
                                            <div>
                                                <input type="text" name="visitcity" placeholder="city" />
                                            </div>
                                            <div>
                                                <input type="text" name="visitplace" placeholder="place" />
                                            </div>
                                        </div>
                                        <div>
                                            <input type="number" name="contactindia" placeholder="contact phone no. in india" />
                                        </div>
                                        <div>
                                            <input type="number" name="mobileindia" placeholder="mobile no. in india" />
                                        </div>
                                        <div>
                                            <input type="number" name="contactcountry" placeholder="contact phone no.(permanently residing country)" />
                                        </div>


                                        <div>
                                            <input type="number" name="mobilecountry" placeholder="mobile no.(permanently residing country)" />
                                        </div>
                                        <div>
                                            <input type="text" name="remark" placeholder="Remarks(if any)" />
                                        </div>
                                    </div>
                                </fieldset>
                            </form>
                        </div>

                        <!-- 
    Cform end
-->
                        <div>

                            <input type="text" list="nationality" name="nationality" placeholder="nationality" value="<?php if (isset($_GET['nationality'])) echo $_GET['nationality'] ?>" />
                            <datalist id="nationality">
                                <option value="afghan">Afghan</option>
                                <option value="albanian">Albanian</option>
                                <option value="algerian">Algerian</option>
                                <option value="american">American</option>
                                <option value="andorran">Andorran</option>
                                <option value="angolan">Angolan</option>
                                <option value="antiguans">Antiguans</option>
                                <option value="argentinean">Argentinean</option>
                                <option value="armenian">Armenian</option>
                                <option value="australian">Australian</option>
                                <option value="austrian">Austrian</option>
                                <option value="azerbaijani">Azerbaijani</option>
                                <option value="bahamian">Bahamian</option>
                                <option value="bahraini">Bahraini</option>
                                <option value="bangladeshi">Bangladeshi</option>
                                <option value="barbadian">Barbadian</option>
                                <option value="barbudans">Barbudans</option>
                                <option value="batswana">Batswana</option>
                                <option value="belarusian">Belarusian</option>
                                <option value="belgian">Belgian</option>
                                <option value="belizean">Belizean</option>
                                <option value="beninese">Beninese</option>
                                <option value="bhutanese">Bhutanese</option>
                                <option value="bolivian">Bolivian</option>
                                <option value="bosnian">Bosnian</option>
                                <option value="brazilian">Brazilian</option>
                                <option value="british">British</option>
                                <option value="bruneian">Bruneian</option>
                                <option value="bulgarian">Bulgarian</option>
                                <option value="burkinabe">Burkinabe</option>
                                <option value="burmese">Burmese</option>
                                <option value="burundian">Burundian</option>
                                <option value="cambodian">Cambodian</option>
                                <option value="cameroonian">Cameroonian</option>
                                <option value="canadian">Canadian</option>
                                <option value="cape verdean">Cape Verdean</option>
                                <option value="central african">Central African</option>
                                <option value="chadian">Chadian</option>
                                <option value="chilean">Chilean</option>
                                <option value="chinese">Chinese</option>
                                <option value="colombian">Colombian</option>
                                <option value="comoran">Comoran</option>
                                <option value="congolese">Congolese</option>
                                <option value="costa rican">Costa Rican</option>
                                <option value="croatian">Croatian</option>
                                <option value="cuban">Cuban</option>
                                <option value="cypriot">Cypriot</option>
                                <option value="czech">Czech</option>
                                <option value="danish">Danish</option>
                                <option value="djibouti">Djibouti</option>
                                <option value="dominican">Dominican</option>
                                <option value="dutch">Dutch</option>
                                <option value="east timorese">East Timorese</option>
                                <option value="ecuadorean">Ecuadorean</option>
                                <option value="egyptian">Egyptian</option>
                                <option value="emirian">Emirian</option>
                                <option value="equatorial guinean">Equatorial Guinean</option>
                                <option value="eritrean">Eritrean</option>
                                <option value="estonian">Estonian</option>
                                <option value="ethiopian">Ethiopian</option>
                                <option value="fijian">Fijian</option>
                                <option value="filipino">Filipino</option>
                                <option value="finnish">Finnish</option>
                                <option value="french">French</option>
                                <option value="gabonese">Gabonese</option>
                                <option value="gambian">Gambian</option>
                                <option value="georgian">Georgian</option>
                                <option value="german">German</option>
                                <option value="ghanaian">Ghanaian</option>
                                <option value="greek">Greek</option>
                                <option value="grenadian">Grenadian</option>
                                <option value="guatemalan">Guatemalan</option>
                                <option value="guinea-bissauan">Guinea-Bissauan</option>
                                <option value="guinean">Guinean</option>
                                <option value="guyanese">Guyanese</option>
                                <option value="haitian">Haitian</option>
                                <option value="herzegovinian">Herzegovinian</option>
                                <option value="honduran">Honduran</option>
                                <option value="hungarian">Hungarian</option>
                                <option value="icelander">Icelander</option>
                                <option value="indian">Indian</option>
                                <option value="indonesian">Indonesian</option>
                                <option value="iranian">Iranian</option>
                                <option value="iraqi">Iraqi</option>
                                <option value="irish">Irish</option>
                                <option value="israeli">Israeli</option>
                                <option value="italian">Italian</option>
                                <option value="ivorian">Ivorian</option>
                                <option value="jamaican">Jamaican</option>
                                <option value="japanese">Japanese</option>
                                <option value="jordanian">Jordanian</option>
                                <option value="kazakhstani">Kazakhstani</option>
                                <option value="kenyan">Kenyan</option>
                                <option value="kittian and nevisian">Kittian and Nevisian</option>
                                <option value="kuwaiti">Kuwaiti</option>
                                <option value="kyrgyz">Kyrgyz</option>
                                <option value="laotian">Laotian</option>
                                <option value="latvian">Latvian</option>
                                <option value="lebanese">Lebanese</option>
                                <option value="liberian">Liberian</option>
                                <option value="libyan">Libyan</option>
                                <option value="liechtensteiner">Liechtensteiner</option>
                                <option value="lithuanian">Lithuanian</option>
                                <option value="luxembourger">Luxembourger</option>
                                <option value="macedonian">Macedonian</option>
                                <option value="malagasy">Malagasy</option>
                                <option value="malawian">Malawian</option>
                                <option value="malaysian">Malaysian</option>
                                <option value="maldivan">Maldivan</option>
                                <option value="malian">Malian</option>
                                <option value="maltese">Maltese</option>
                                <option value="marshallese">Marshallese</option>
                                <option value="mauritanian">Mauritanian</option>
                                <option value="mauritian">Mauritian</option>
                                <option value="mexican">Mexican</option>
                                <option value="micronesian">Micronesian</option>
                                <option value="moldovan">Moldovan</option>
                                <option value="monacan">Monacan</option>
                                <option value="mongolian">Mongolian</option>
                                <option value="moroccan">Moroccan</option>
                                <option value="mosotho">Mosotho</option>
                                <option value="motswana">Motswana</option>
                                <option value="mozambican">Mozambican</option>
                                <option value="namibian">Namibian</option>
                                <option value="nauruan">Nauruan</option>
                                <option value="nepalese">Nepalese</option>
                                <option value="new zealander">New Zealander</option>
                                <option value="ni-vanuatu">Ni-Vanuatu</option>
                                <option value="nicaraguan">Nicaraguan</option>
                                <option value="nigerien">Nigerien</option>
                                <option value="north korean">North Korean</option>
                                <option value="northern irish">Northern Irish</option>
                                <option value="norwegian">Norwegian</option>
                                <option value="omani">Omani</option>
                                <option value="pakistani">Pakistani</option>
                                <option value="palauan">Palauan</option>
                                <option value="panamanian">Panamanian</option>
                                <option value="papua new guinean">Papua New Guinean</option>
                                <option value="paraguayan">Paraguayan</option>
                                <option value="peruvian">Peruvian</option>
                                <option value="polish">Polish</option>
                                <option value="portuguese">Portuguese</option>
                                <option value="qatari">Qatari</option>
                                <option value="romanian">Romanian</option>
                                <option value="russian">Russian</option>
                                <option value="rwandan">Rwandan</option>
                                <option value="saint lucian">Saint Lucian</option>
                                <option value="salvadoran">Salvadoran</option>
                                <option value="samoan">Samoan</option>
                                <option value="san marinese">San Marinese</option>
                                <option value="sao tomean">Sao Tomean</option>
                                <option value="saudi">Saudi</option>
                                <option value="scottish">Scottish</option>
                                <option value="senegalese">Senegalese</option>
                                <option value="serbian">Serbian</option>
                                <option value="seychellois">Seychellois</option>
                                <option value="sierra leonean">Sierra Leonean</option>
                                <option value="singaporean">Singaporean</option>
                                <option value="slovakian">Slovakian</option>
                                <option value="slovenian">Slovenian</option>
                                <option value="solomon islander">Solomon Islander</option>
                                <option value="somali">Somali</option>
                                <option value="south african">South African</option>
                                <option value="south korean">South Korean</option>
                                <option value="spanish">Spanish</option>
                                <option value="sri lankan">Sri Lankan</option>
                                <option value="sudanese">Sudanese</option>
                                <option value="surinamer">Surinamer</option>
                                <option value="swazi">Swazi</option>
                                <option value="swedish">Swedish</option>
                                <option value="swiss">Swiss</option>
                                <option value="syrian">Syrian</option>
                                <option value="taiwanese">Taiwanese</option>
                                <option value="tajik">Tajik</option>
                                <option value="tanzanian">Tanzanian</option>
                                <option value="thai">Thai</option>
                                <option value="togolese">Togolese</option>
                                <option value="tongan">Tongan</option>
                                <option value="trinidadian or tobagonian">Trinidadian or Tobagonian</option>
                                <option value="tunisian">Tunisian</option>
                                <option value="turkish">Turkish</option>
                                <option value="tuvaluan">Tuvaluan</option>
                                <option value="ugandan">Ugandan</option>
                                <option value="ukrainian">Ukrainian</option>
                                <option value="uruguayan">Uruguayan</option>
                                <option value="uzbekistani">Uzbekistani</option>
                                <option value="venezuelan">Venezuelan</option>
                                <option value="vietnamese">Vietnamese</option>
                                <option value="welsh">Welsh</option>
                                <option value="yemenite">Yemenite</option>
                                <option value="zambian">Zambian</option>
                                <option value="zimbabwean">Zimbabwean</option>

                            </datalist>
                        </div>
                        <div>

                            <input type="text" list="category" name="category" placeholder="Special-Category" value="<?php if (isset($_GET['category'])) echo $_GET['category'] ?>" />
                            <datalist id="category">
                                <option value="Crew">Crew</option>
                                <option value="Diplomat Exempted">Diplomat Exempted</option>
                                <option value="Emergency Transit">Emergency Transit</option>
                                <option value="Loss of passport">Loss of passport</option>
                                <option value="OCI">OCI</option>
                                <option value="Official Exempted">Official Exempted</option>
                                <option value="Other Exempted">Other Exempted</option>
                                <option value="Newly born">Newly born</option>
                                <option value="PIO">PIO</option>
                                <option value="Refugee">Refugee</option>
                                <option value="TLP">TLP</option>
                                <option value="Others">Others</option>


                            </datalist>
                        </div>
                        <div>

<input type="text" list="visit" name="visit" placeholder="purpose of visit" />
<datalist id="visit">
    <option value="ACCOMPANYING PARENTS">ACCOMPANYING PARENTS</option>
    <option value="ACCOMPANYING PATIENT">ACCOMPANYING PATIENT</option>
    <option value="ACCOMPANYING PARENTS AS DOCTOR">ACCOMPANYING PARENTS AS DOCTOR</option>
    <option value="ACCOMPANYING SPOUSE">ACCOMPANYING SPOUSE</option>
    <option value="BUSINESS">BUSINESS</option>
    <option value="DIPLOMATIC">DIPLOMATIC</option>
    <option value="EDUCATION">EDUCATION</option>
    <option value="EMPLOYEMENT">EMPLOYEMENT</option>
    <option value="INTERNSHIP">INTERNSHIP</option>
    <option value="JOINING SPOUSE">JOINING SPOUSE</option>
    <option value="JOURNALISM">JOURNALISM</option>
    <option value="MEDICAL TREATMENT OF SELF">MEDICAL TREATMENT OF SELF</option>
    <option value="MEETING FIREND/RELATIVES">MEETING FIREND/RELATIVES</option>
    <option value="MINOR CHILD(EITHER PARENTS IS INDIAN)">MINOR CHILD(EITHER PARENTS IS INDIAN)</option>
    <option value="OFFICE">OFFICE</option>
    <option value="OTHERS">OTHERS</option>
    <option value="SEMINAR/CONFERENCE IN INDIA">SEMINAR/CONFERENCE IN INDIA</option>
    <option value="STUDIES">STUDIES</option>
    <option value="SURROGANCY">SURROGANCY</option>
    <option value="TOURISM">TOURISM</option>
</datalist>
</div>
                        <div>

                            <input type="text" name="fromcity" placeholder="Arrival from city" value="<?php if (isset($_GET['fromcity'])) echo $_GET['fromcity'] ?>" />
                        </div>
                        <div>

                            <input type="text" name="tocity" placeholder="Departure to city" value="<?php if (isset($_GET['tocity'])) echo $_GET['tocity'] ?>" />
                        </div>
                        <div>

                            <input type="text" name="travelmedium" LIST="TRAVEL" placeholder="BY BUS" value="<?php if (isset($_GET['travelmedium'])) echo $_GET['travelmedium'] ?>" />
                        <datalist id="TRAVEL">
                            <option value="BY AIR">BY AIR</option>
                            <option value="BY TRAIN">BY TRAIN</option>
                            <option value="BY BUS">BY BUS</option>
                            <option value="BY TAXI">BY TAXI</option>
                            <option value="BY OWNED VEHICLE">BY OWNED VEHICLE</option>
                        </datalist>
                        </div>
                        <div>

                            <input type="text" name="travelno" placeholder="PNR No./Vehicle No./Taxi No./Ticket No." value="<?php if (isset($_GET['travelno'])) echo $_GET['travelno'] ?>" />
                        </div>
                        <div>
                            <div style="float:left;">
                                <select>
                                    <option>+91</option>
                                </select>
                            </div>
                            <div style="float:right;width:87.5%;">
                                <input type="text" name="phone" placeholder="Contact-Number" maxlength="10" value="<?php if (isset($_GET['phone'])) echo $_GET['phone'] ?>" />
                            </div>
                        </div>
                        <div>
                            <input type="text" name="email" placeholder="E-mail" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" value="<?php if (isset($_GET['email'])) echo $_GET['email'] ?>" />
                        </div>
                        <div>
                            <label>Marital Status :</label>


                            <input type="radio" name="marital" class="radio2" value="Y" <?php if (isset($_GET['marital']) && ($_GET['marital']) == 'Y') {
                                                                                            echo "checked";
                                                                                        } ?> /><label>Yes</label>

                            <input type="radio" name="marital" class="radio2" value="N" <?php if (isset($_GET['marital']) && ($_GET['marital']) == 'N') {
                                                                                            echo "checked";
                                                                                        } ?> /><label>No</label>


                        </div>
                        <div style="text-transform: uppercase;">

                            <input type="text" list="documents" name="idproof" placeholder="Id-Proof" value="<?php if (isset($_GET['idproof'])) echo $_GET['idproof'] ?>" />
                            <datalist id="documents">
                                <option value="ADHAAR CARD">ADHAAR CARD</option>
                                <option value="DRIVING LICENCE">DRIVING LICENCE</option>
                                <option value="ARMS LICENCE WITH PHOTO">ARMS LICENCE WITH PHOTO</option>
                                <option value="PASSPORT">PASSPORT</option>
                                <option value="PAN CARD">PAN CARD</option>
                                <option value="VOTER ID CARD">VOTER ID CARD</option>
                                <option value="RATION CARD WITH PHOTO">RATION CARD WITH PHOTO</option>
                                <option value="GOVT. INSTITUTE ID CARD">GOVT. INSTITUTE ID CARD</option>
                                <option value="CREDIT CARD WITH PHOTO">CREDIT CARD WITH PHOTO</option>
                                <option value="KISHAN CARD WITH PHOTO">KISHAN CARD WITH PHOTO</option>
                            </datalist>
                            <input type="text" name="number" placeholder="Id-proof Number" value="<?php if (isset($_GET['number'])) echo $_GET['number'] ?>"  />
                        </div>
                        
                        <div>
                            <input type="file" name="idimage" />
                        </div>
                        <div>
                            <input type="submit" class="btn1"></input>

                        </div>
                    </div>
                </fieldset>
            </form>

            <div style="float:center;">


                <table class="tbl">
                    <tr>
                        <th>Guest id</th>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Surname</th>
                        <th>Gender</th>
                        <th>DOB</th>
                        <th>Age</th>
                        <th>Address</th>
                        <th>Pincode</th>
                        <th>State</th>
                        <th>Country</th>
                        <th>Nationality</th>
                        <th>Special category</th>
                        <th>Visit Purpose</th>
                        <th>FROM CITY</th>
                        <th>TO CITY</th>
                        <th>TRAVEL MEDIUM</th>
                        <th>TRAVEL MEDIUM NO.</th>
                        <th>Contact No.</th>
                        <th>E-mail</th>
                        <th>Marital</th>
                        <th>Id-Proof</th>
                        <th>Id-Proof Photo</th>
                        <th>Id-Proof Nuber</th>
                        <th>Active</th>
                    </tr>
                    <?php
                    include_once dirname(__FILE__) . './dbDetails.php';
                    $conn = new mysqli(dbhost, dbusername, dbpass, dbName);
                    $guestid = 0;
                    if ($conn->connect_error) {
                        die("connection failed :" . $conn->connect_error);
                    }
                    $sql = "SELECT * FROM guest_details ORDER BY GUEST_ID DESC";

                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>";

                            echo "<a class='actionicon' href='./bookingdetail.php?guestid=" . $row['GUEST_ID'] . "&username=" . $row['NAME'] . "&surname=" . $row['SURNAME'] . "'>";
                            echo  $row['GUEST_ID'];
                            echo "</a>";
                            echo "</td>";
                            echo "<td>";
                            echo "<img src='./images/" . $row['IMAGE'] . "'  height='100px' width='100px'/>";
                            echo "</td>";
                            echo "<td>";
                            echo $row['NAME'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['SURNAME'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['GENDER'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['DOB'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['AGE'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['ADDRESS'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['PINCODE'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['STATE'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['COUNTRY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['NATIONALITY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['SPECIAL_CATEGORY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['VISIT_PURPOSE'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['FROMCITY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['TOCITY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['TRAVELMEDIUM'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['TRAVELNO'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['CONTACT_NO'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['EMAIL'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['MARITAL_STATUS'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['ID_PROOF'];
                            echo "</td>";
                            echo "<td>";
                            echo "<img src='./images/" . $row['ID_IMAGE'] . "'  height='100px' width='100px'/>";
                            echo "</td>";
                            echo "<td>";
                            echo $row['ID_PROOF_NO'];
                            echo "</td>";
                            echo "<td>";
                            echo "<span style='float: left;'><a class='onicon' href='./guest.php?guestid=" . $row['GUEST_ID'] . "&username=" . $row['NAME'] . "&age=" . $row['AGE'] . "&DOB=" . $row['DOB'] . "&surname=" . $row['SURNAME'] . "&visit=" . $row['VISIT_PURPOSE'] . "&address=" . $row['ADDRESS'] . "&pincode=" . $row['PINCODE'] . "&states=" . $row['STATE'] . "&country=" . $row['COUNTRY'] . "&nationality=" . $row['NATIONALITY'] . "&category=" . $row['SPECIAL_CATEGORY'] . "&phone=" . $row['CONTACT_NO'] . "&email=" . $row['EMAIL'] . "&gender=" . $row['GENDER'] . "&marital=" . $row['MARITAL_STATUS'] . "&idproof=" . $row['ID_PROOF'] . "&number=" . $row['ID_PROOF_NO'] . "&fromcity=" . $row['FROMCITY'] . "&tocity=" . $row['TOCITY'] . "&travelmedium=" . $row['TRAVELMEDIUM'] . "&travelno=" . $row['TRAVELNO'] . "'>";
                            echo "<i class='fa fa-pencil-alt'></i></a></span>";
                            echo "<span style='float: right;'><a class='actionicon' href='./guest.php?deleteguestid=" . $row['GUEST_ID'] . "'>";
                            echo "<i class='fa fa-trash-alt'></i></a></span></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo " Empty";
                    }
                    $conn->close();

                    ?>
                </table>
            </div>
        </div>
</body>


</html>