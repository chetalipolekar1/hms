<!DOCTYPE html>
<html>

<head>
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />

  
</head>

<body>


    <div>



        <?php

        include_once dirname(__FILE__) . './dbDetails.php';

        if (isset($_POST['roomno'])) {                   //code to save room

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);  //create conncetion

            if ($conn->connect_error)                              //check connection
            {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "INSERT INTO ROOM VALUES(" . $_POST['roomno'] . ", '" . $_POST['roomtype'] . "')";

            //insert value
            if ($conn->query($sql) === TRUE) {

                echo "New Room added successfully";
            } else {
                echo "Error: " . "<br>" . $conn->error;
            }
            $conn->close();
        }


        //code to delete 
        if (isset($_GET['deleteRoomNo'])) {

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "DELETE FROM ROOM WHERE ROOM_NO = " . $_GET['deleteRoomNo'];

            if ($conn->query($sql) === TRUE) {
                echo "Room Number " .  $_GET['deleteRoomNo'] .  " deleted succesfully.";
            } else {
                echo "Error deleting room" . $conn->error;
            }
            $conn->close();
        }
        ?>
        <div>
            <div style="float:left;">
                <form action="./addRoom.php" method="POST">
                    <fieldset class="room">
                        <legend>Room :</legend>
                        <div>
                            <div>

                                <input placeholder="Room Number" type="number" name="roomno" min="1" />
                            </div>
                            <div>
                                <input placeholder="Room Type" type="text" name="roomtype" />
                            </div>

                            <div>
                                <input type="submit" class="btn1" value="save"></input>

                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>

        <div style="float:center;">


            <table class="tbl">
                <tr>
                    <th>Room No.</th>

                    <th>Room Type</th>
                    <th>Active</th>
                </tr>

                <?php                                                       // select from table
                include_once dirname(__FILE__) . './dbDetails.php';

                $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                if ($conn->connect_error) {
                    die("connection failed :" . $conn->connect_error);
                }
                $sql = "SELECT * FROM ROOM ORDER BY ROOM_NO";

                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>";
                        echo $row['ROOM_NO'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['ROOM_TYPE'];
                        echo "</td>";
                        echo "<td>";
                        echo "<span><a class='actionicon' href='./addRoom.php?deleteRoomNo=" . $row['ROOM_NO'] . "'>";
                        echo "<i class='fa fa-trash-alt'></i></a></span></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "Empty";
                }


                ?>
            </table>
        </div>
    </div>
</body>

</html>