<!DOCTYPE html>
<html>

<head>  
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div style="float:center;margin:8%;">


<table class="tbl">
    <tr>


        <th>DATE</th>
        <th>DESCRIPTION</th>
        <th>DETAIL</th>
        <th>AMOUNT</th>
        <th>Active</th>
    </tr>

    <?php                                                       // select from table
    include_once dirname(__FILE__) . './dbDetails.php';

    $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

    if ($conn->connect_error) {
        die("connection failed :" . $conn->connect_error);
    }
    $sql = "SELECT `EXP_ID`, `DATE`, `DESCRIPTION`,`DETAIL`, `AMOUNT` FROM `expense` where DESCRIPTION='".$_GET['description']. "'  ORDER BY EXP_ID";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {


            echo "<tr id='select'><td>";
            echo "<a class='actioicon'>";
            echo $row['DATE'];
            echo "</a>";
            echo "</td>";
            echo "<td>"; 
            echo $row['DESCRIPTION'];
            echo "</td>";
            echo "<td>"; 
            echo $row['DETAIL'];
            echo "</td>";
            echo "<td>";
            echo $row['AMOUNT'];
            echo "</td>";
            echo "<td><span style='float: left;'><a class='onicon' href='./expense.php?expenseid=" . $row['EXP_ID'] . "&discription=" . $row['DESCRIPTION'] . "&detail=" . $row['DETAIL'] . "&date=" . $row['DATE'] . "&amount=" . $row['AMOUNT'] . "'>";
            echo "<i class='fa fa-pencil-alt'></i></a></span>";
            echo "<span style='float: right;'><a class='actionicon' href='./expense.php?deleteexpenseid=" . $row['EXP_ID'] . "'>";
            echo "<i class='fa fa-trash-alt'></i></a></span>";
            echo "</td>";
            echo "</tr>";
        }
    } else {
        echo " Empty";
    }

    $conn->close();
    ?>
</table>

</div>



</body>
</html>