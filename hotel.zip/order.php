<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />

</head>

<body>


    <div>



        <?php

        include_once dirname(__FILE__) . './dbDetails.php';

        if (isset($_POST['id']) && $_POST['id'] != '') {
            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);
            if ($conn->connect_error) {
                die("connection error :" . $conn->connect_error);
            }
            $sql = "UPDATE orderitem SET BOOKING_ID=" . $_POST['bookingid'] . ", NAME='" . $_POST['username'] . "',SURNAME='" . $_POST['surname'] . "',  NameOfItems='" . $_POST['nameofitem'] . "', Amount=" . $_POST['amount'] . ", NumberOfItems =" . $_POST['noofitem'] . " ,DISCOUNT=" . $_POST['discount'] . ",DISCOUNT_AS='" . $_POST['discountAs'] . "',TAX=" . $_POST['tax'] . ",TAX_AMOUNT=" . $_POST['taxamount'] . ",NET_AMOUNT=" . $_POST['net'] . " WHERE ID = " . $_POST['id'];

            if ($conn->query($sql) === TRUE) {
                echo "updated succesfully";
            } else {
                echo "error "  . "</br>" . $conn->error;
            }
            $conn->close();
        } else  if (isset($_POST['noofitem'])) {                   //code to save room

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);  //create conncetion

            if ($conn->connect_error)                              //check connection
            {
                die("connection failed :" . $conn->connect_error);
            }
            $sql = "INSERT INTO orderitem(BOOKING_ID,NAME,SURNAME,NameOfItems,NumberOfItems,Amount,DISCOUNT,DISCOUNT_AS, TAX,TAX_AMOUNT,NET_AMOUNT) VALUES(" . $_POST['bookingid'] . ",'" . $_POST['username'] . "','" . $_POST['surname'] . "','" . $_POST['nameofitem'] . "'," . $_POST['noofitem'] . ", " . $_POST['amount'] . "," . $_POST['discount'] . ",'" . $_POST['discountAs'] . "'," . $_POST['tax'] . "," . $_POST['taxamount'] . "," . $_POST['net'] . ")";

            //insert value
            if ($conn->query($sql) === TRUE) {

                echo "New Order Item added successfully";
            } else {
                echo "Error: " . "<br>" . $conn->error;
            }
            $conn->close();
        }


        //code to delete 
        if (isset($_GET['deleteid'])) {

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "DELETE FROM orderitem WHERE ID = " . $_GET['deleteid'];

            if ($conn->query($sql) === TRUE) {
                echo  " deleted succesfully.";
            } else {
                echo "Error deleting name" . $conn->error;
            }
            $conn->close();
        }

        ?>
        <div>
            <div style="float:left;">
                <form action="./order.php" method="POST">
                    <fieldset class="room">
                        <legend>Order Item :</legend>
                        <div>
                            <div>
                                <input name="id" type="hidden" value="<?php if (isset($_GET['id'])) echo $_GET['id'] ?>" />

                                <input placeholder="Booking Id" name="bookingid" value="<?php if (isset($_GET['bookingid'])) echo $_GET['bookingid'] ?>" />
                            </div>
                            <input type="text" name="username" placeholder="Name" maxlength="30" value="<?php if (isset($_GET['username'])) echo $_GET['username'] ?>" />
                            <div>

                                <input type="text" name="surname" placeholder="Surname" maxlength="30" value="<?php if (isset($_GET['surname'])) echo $_GET['surname'] ?>" />
                            </div>
                            <div>

                                <input placeholder="Name of Item" type="text" name="nameofitem" value="<?php if (isset($_GET['nameofitem'])) echo $_GET['nameofitem'] ?>" />
                            </div>
                            <div>

                                <input placeholder="No. of Item" id="item" type="text" name="noofitem" min="0" value="<?php if (isset($_GET['noofitem'])) echo $_GET['noofitem'] ?>" />
                            </div>
                            <div>
                                <input placeholder="Rate" id="rate" type="text" name="amount" value="<?php if (isset($_GET['amount'])) echo $_GET['amount'] ?>" />
                            </div>
                            <div>
                                <div style="float:left;width:23%;">
                                    <label>Discount :</label>

                                </div>

                                <div style="float:left;width:58.5%;">

                                    <input type="text" id="calc" name="discount" value="<?php if (isset($_GET['discount'])) echo $_GET['discount'] ?>" />
                                </div>
                                <div style="float:left;width:18.5%;" onclick="calDiscount()">
                                    <input type="text" style="background-color: #346d9e;color: #000000;margin-top: 6px;;font-weight:bold;font-size:large;border:none;height:18px;border: 1px solid;border-radius: 4px;" readonly id="discountAs" name="discountAs" value="<?php if (isset($_GET['discountAs'])) {
                                                                                                                                                                                                                                                                                echo $_GET['discountAs'];
                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                echo "%";
                                                                                                                                                                                                                                                                            }

                                                                                                                                                                                                                                                                            ?>">
                                </div>
                            </div>

                            <div>
                                <div style="float:left;">
                                    <label>GST-Tax :</label>

                                </div>
                                <div style="float:right;width:78.5%;">
                                    <input type="text" id="tax" onchange="calculateTotal()" name="tax" value="<?php if (isset($_GET['tax'])) echo $_GET['tax'] ?>" />
                                </div>
                            </div>
                            <div>
                                <div style="float:left;">
                                    <label>GST-Amount :</label>

                                </div>
                                <div style="float:right;width:78.5%;">
                                    <input type="text" id="taxamount" name="taxamount" value="<?php if (isset($_GET['taxamount'])) echo $_GET['taxamount'] ?>" />
                                </div>
                            </div>
                            <div style="float:left;width:98.5%;">
                                <label>Total-Amount :</label>
                                <div style="float:right;width:69.5%;">
                                    <input type="text" id="totalamount" name="net" value="<?php if (isset($_GET['net'])) echo $_GET['net'] ?>" />
                                </div>
                                <div>
                                    <input type="submit" class="btn1" value="save"></input>

                                </div>
                            </div>
                    </fieldset>
                </form>
            </div>
        </div>

        <div style="float:center;">


            <table class="tbl">
                <tr>
                    <th>Booking Id</th>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>Item</th>
                    <th>Quantity</th>
                    <th>Rate</th>
                    <th>Amount</th>
                    <th>Discount</th>
                    <th>Net-Amount</th>
                    <th>GST Rate(%)</th>
                    <th>Total TAX</th>
                    <th>Total-Amount</th>
                    <th>Active</th>
                </tr>

                <?php                                                       // select from table
                include_once dirname(__FILE__) . './dbDetails.php';

                $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                if ($conn->connect_error) {
                    die("connection failed :" . $conn->connect_error);
                }
                $sql = "SELECT * FROM orderitem ORDER BY BOOKING_ID DESC";

                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>";
                        echo $row['BOOKING_ID'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NAME'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['SURNAME'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NameOfItems'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NumberOfItems'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['Amount'];
                        echo "</td>";
                        echo "<td>";
                        echo ($row['NumberOfItems'] * $row['Amount']);
                        echo "</td>";
                        echo "<td>";
                        $discount = $row['DISCOUNT'];
                        if ($row['DISCOUNT_AS'] == '%') {
                            $discount = (($row['Amount'] * $row['NumberOfItems']) * ($row['DISCOUNT']) / 100);
                        }
                        echo $row['DISCOUNT'];
                        echo $row['DISCOUNT_AS'];
                        echo "</td>";
                        echo "<td>";
                        echo ($row['Amount'] * $row['NumberOfItems'] - $discount);
                        echo "</td>";
                        echo "<td>";
                        echo $row['TAX'];
                        echo "</td>";
                        echo "<td>";
                        $totalTax = ($row['TAX_AMOUNT']);
                        echo  $totalTax;     //Total TAX
                        echo "</td>";
                        echo "<td>";
                        $orderTotal = round($row['NET_AMOUNT'], 2);
                        echo  $orderTotal;
                        echo "</td>";
                        echo "<td><span style='float: left;'><a class='onicon' href='./order.php?id=" . $row['ID'] . "&bookingid=" . $row['BOOKING_ID'] . "&surname=" . $row['SURNAME'] . "&username=" . $row['NAME'] . "&nameofitem=" . $row['NameOfItems'] . "&noofitem=" . $row['NumberOfItems'] . "&amount=" . $row['Amount'] . "&net=" . $row['NET_AMOUNT'] . "&discount=" . $row['DISCOUNT'] . "&discountAs=" . $row['DISCOUNT_AS'] . "&tax=" . $row['TAX'] . "&taxamount=" . $row['TAX_AMOUNT'] . "'>";
                        echo "<i class='fa fa-pencil-alt'></i></a></span>";
                        echo "<span style='float: right;'><a class='actionicon' href='./order.php?deleteid=" . $row['ID'] . "'>";
                        echo "<i class='fa fa-trash-alt'></i></a></span>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo " Empty";
                }
                $conn->close();

                ?>
            </table>
        </div>
    </div>
    <script>
        function calDiscount() {
            var x = document.getElementById("discountAs");
            if (x.value == "%") {
                x.value = "₹";
            } else {
                x.value = "%";
            }
            calculateGSTTotal();
        }

        function calculateTotal() {
            var item = document.getElementById("item").value;
            var rate = document.getElementById("rate").value;
            var discount = document.getElementById("calc").value;
            var discountAs = document.getElementById("discountAs").value;
            var tax = document.getElementById("tax").value;
            if (discountAs === '%') {
                var ans = ((item * rate) - item * rate * (discount / 100)) + (item * rate - item * rate * (discount / 100)) * (tax / 100);
            } else {
                var ans = (item * rate - (discount) + (item * rate - discount) * (tax / 100));
            }
            totalamount.value = ans;
            calculateGSTTotal();
        }

        function calculateGSTTotal() {
            var item = document.getElementById("item").value;
            var rate = document.getElementById("rate").value;
            var discount = document.getElementById("calc").value;
            var discountAs = document.getElementById("discountAs").value;
            var tax = document.getElementById("tax").value;
            if (discountAs === '%') {
                var ans = ((item * rate) - (item * rate * (discount / 100))) * (tax / 100);
            } else {
                var ans = (((item * rate) - discount) * (tax / 100));
            }
            taxamount.value = ans;
        }
    </script>
</body>

</html>