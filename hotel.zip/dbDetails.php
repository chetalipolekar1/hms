<?php

define('dbName','hotel');
define('dbusername','root');
define('dbpass','');
define('dbhost','localhost');



?>
