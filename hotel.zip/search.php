<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
      <h3>Guest-Detail :</h3>

      <div>
    <table class="tbl">
                    <tr>
                        <th>Guest id</th>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Surname</th>
                        <th>Gender</th>
                        <th>DOB</th>
                        <th>Age</th>
                        <th>Address</th>
                        <th>Pincode</th>
                        <th>State</th>
                        <th>Country</th>
                        <th>Nationality</th>
                        <th>Special category</th>
                        <th>Visit Purpose</th>
                        <th>FROM CITY</th>
                        <th>TO CITY</th>
                        <th>TRAVEL MEDIUM</th>
                        <th>TRAVEL MEDIUM NO.</th>
                        <th>Contact No.</th>
                        <th>E-mail</th>
                        <th>Marital</th>
                        <th>Id-Proof</th>
                        <th>Id-Proof Nuber</th>
                        
                    </tr>
        <?php                                                       // select from table
        include_once dirname(__FILE__) . './dbDetails.php';

        $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

        if ($conn->connect_error) {
            die("connection failed :" . $conn->connect_error);
        }
        $sql = "SELECT * from  guest_details WHERE CONCAT_WS(NAME,GUEST_ID,SURNAME,COUNTRY) LIKE '%".$_GET['searchText']."%'";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
          // output data of each row
          while ($row = $result->fetch_assoc()) {
              echo "<tr>";
              echo "<td>";
              echo  $row['GUEST_ID'];
              echo "</td>";
              echo "<td>";
              echo "<img src='./images/" . $row['IMAGE'] . "'  height='100px' width='100px'/>";
              echo "</td>";
              echo "<td>";
              echo $row['NAME'];
              echo "</td>";
              echo "<td>";
              echo $row['SURNAME'];
              echo "</td>";
              echo "<td>";
              echo $row['GENDER'];
              echo "</td>";
              echo "<td>";
              echo $row['DOB'];
              echo "</td>";
              echo "<td>";
              echo $row['AGE'];
              echo "</td>";
              echo "<td>";
              echo $row['ADDRESS'];
              echo "</td>";
              echo "<td>";
              echo $row['PINCODE'];
              echo "</td>";
              echo "<td>";
              echo $row['STATE'];
              echo "</td>";
              echo "<td>";
              echo $row['COUNTRY'];
              echo "</td>";
              echo "<td>";
              echo $row['NATIONALITY'];
              echo "</td>";
              echo "<td>";
              echo $row['SPECIAL_CATEGORY'];
              echo "</td>";
              echo "<td>";
              echo $row['VISIT_PURPOSE'];
              echo "</td>";
              echo "<td>";
              echo $row['FROMCITY'];
              echo "</td>";
              echo "<td>";
              echo $row['TOCITY'];
              echo "</td>";
              echo "<td>";
              echo $row['TRAVELMEDIUM'];
              echo "</td>";
              echo "<td>";
              echo $row['TRAVELNO'];
              echo "</td>";
              echo "<td>";
              echo $row['CONTACT_NO'];
              echo "</td>";
              echo "<td>";
              echo $row['EMAIL'];
              echo "</td>";
              echo "<td>";
              echo $row['MARITAL_STATUS'];
              echo "</td>";
              echo "<td>";
              echo $row['ID_PROOF'];
              echo "</td>";
              echo "<td>";
              echo $row['ID_PROOF_NO'];
              echo "</td>";
              echo "</tr>";
          }
      } else {
          echo " ";
      }
      $conn->close();

      ?>
  </table>
    </div>

    <h3>Booking-Detail :</h3>
  
  <div>
  <table class="tbl">
                <tr>
                    <th>Booking id</th>
                    <th>Guest id</th>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>Room No.</th>
                    <th>Room Type</th>
                    <th>No. of days</th>
                    <th>No. of members</th>
                    <th>bed</th>
                    <th>Check-in</th>
                    <th>Check-out</th>
                    
                </tr>
                <?php
                include_once dirname(__FILE__) . './dbDetails.php';
                $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                if ($conn->connect_error) {
                    die("connection failed :" . $conn->connect_error);
                }
                $sql = "SELECT * FROM booking_details WHERE CONCAT_WS(NAME,BOOKING_ID,SURNAME,ROOM_NO) LIKE '%".$_GET['searchText']."%' ";

                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {

                        echo "<tr>";
                        echo "<td>";
                        echo $row['BOOKING_ID'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['GUEST_ID'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NAME'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['SURNAME'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['ROOM_NO'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['ROOM_TYPE'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NO_OF_DAYS'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NO_OF_MEMBERS'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['BED'];
                        echo "</td>";
                        echo "<td>";
                        $newDate = strtotime($row['CHECK_IN']);
                        echo date("d-m-y H:i:sa", $newDate);
                        echo "</td>";
                        echo "<td>";
                        $newDate = '';

                        if (!$row['CHECK_OUT'] == null || !$row['CHECK_OUT'] == '') {

                            $newDate = strtotime($row['CHECK_OUT']);
                            $newDate = date("d-m-y H:i:sa", $newDate);
                        }
                        echo $newDate;
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo " ";
                }
                $conn->close();

                ?>
            </table>
    </div>
  
    <h3>Billing-Detail :</h3>
    
       <div>
         
        <table class="tbl" class="table" id="comparisonTable">
            <tr>
                <th>Booking Id</th>
                <th>Room No.</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Payment Date</th>
                <th>No. Of Days</th>
                <th>Room Rent/Day</th>
                <th>Amount</th>
                <th>Discount</th>
                <th>Net-Amount</th>
                <th>GST Rate(%)</th>
                <th>GST Amount</th>
                <th>Total-Amount</th>
                <th>Food Bill(Total-Amount)</th>
                <th>Total Payable(Room+Food)</th>
                <th>Payment Via</th>
                <th>Paid</th>
                <th>Remaining</th>
            </tr>

            <?php                                                       // select from table
            include_once dirname(__FILE__) . './dbDetails.php';

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }
            $sql = "SELECT billing.BILL_ID, billing.BOOKING_ID, billing.ROOM_NO, billing.NAME,BILLING.SURNAME, billing.NO_OF_DAYS, billing.RENT,billing.DISCOUNT, billing.DISCOUNT_AS, billing.TAX, billing.date,billing.NET_AMOUNT, billing.PAYMENT_METHOD, billing.PAID , SUM(IFNULL((orderitem.NET_AMOUNT),0)) AS TOTAL_AMOUNT from billing LEFT OUTER JOIN orderitem ON billing.BOOKING_ID = orderitem.BOOKING_ID WHERE CONCAT_WS(billing.NAME,billing.BOOKING_ID,BILLING.SURNAME,billing.ROOM_NO) LIKE '%".$_GET['searchText']."%'  GROUP by billing.BOOKING_ID ";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {


                    echo "<tr>";
                    echo "<td>";
                    echo $row['BOOKING_ID'];
                    echo "</td>";
                    echo "<td>";
                    echo $row['ROOM_NO'];
                    echo "</td>";
                    echo "<td>";
                    echo $row['NAME'];
                    echo "</td>";
                    echo "<td>";
                    echo $row['SURNAME'];
                    echo "</td>";
                    echo "<td>";
                    $newDate = strtotime($row['date']);
                    echo date("d-m-y", $newDate);
                    echo "</td>";
                    echo "<td>";
                    echo $row['NO_OF_DAYS'];
                    echo "</td>";
                    echo "<td>";
                    echo $row['RENT'];
                    echo "</td>";
                    echo "<td>";
                    echo ($row['RENT'] * $row['NO_OF_DAYS']);    //Total Rent
                    echo "</td>";
                    echo "<td>";
                    $discount = $row['DISCOUNT'];
                    if ($row['DISCOUNT_AS'] == '%') {
                        $discount = (($row['RENT'] * $row['NO_OF_DAYS']) * ($row['DISCOUNT']) / 100);
                    }
                    echo $row['DISCOUNT'];       //Total TAX
                    echo $row['DISCOUNT_AS'];
                    echo "</td>";
                    echo "<td>";
                    $netAmt =($row['RENT'] * $row['NO_OF_DAYS'] - $discount);
                    echo $netAmt;       
                    echo "</td>";
                    echo "<td>";
                    echo $row['TAX'];
                    echo "</td>";
                    echo "<td>";
                    $totalTax = ($netAmt * ($row['TAX']) / 100);
                    echo $totalTax;       //Total TAX
                    echo "</td>";
                    echo "<td>";
                    $totalAmmount = $netAmt + $totalTax;
                    echo $totalAmmount;       
                    echo "</td>";
                    echo "<td>";
                    $orderTotal=round($row['TOTAL_AMOUNT'],2);
                    echo $orderTotal;
                    echo "</td>";
                    echo "<td  class='hoursA'>";
                    $total= $orderTotal + $totalAmmount;
                    echo $total;
                    echo "</td>";          //Total Payable(if order)
                    echo "<td>";
                    echo $row['PAYMENT_METHOD'];
                    echo "</td>";
                    echo "<td class='hoursB'>";
                    echo $row['PAID'];    //Paid
                    echo "</td>";
                    echo "<td class='difference'>";          //Remaining
                
                    echo round($total - $row['PAID'], 2);
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "";
            }

            $conn->close();
            ?>
        </table>

       </div>

    <h3>Order-Detail :</h3>
  
       <div>
         

       <table class="tbl">
                <tr>
                    <th>Booking Id</th>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>Item</th>
                    <th>Quantity</th>
                    <th>Rate</th>
                    <th>Amount</th>
                    <th>Discount</th>
                    <th>Net-Amount</th>
                    <th>GST Rate(%)</th>
                    <th>Total TAX</th>
                    <th>Total-Amount</th>
                </tr>

                <?php                                                       // select from table
                include_once dirname(__FILE__) . './dbDetails.php';

                $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                if ($conn->connect_error) {
                    die("connection failed :" . $conn->connect_error);
                }
                $sql = "SELECT * FROM orderitem WHERE  CONCAT_WS(NAME,BOOKING_ID,SURNAME) LIKE '%".$_GET['searchText']."%' ORDER BY BOOKING_ID ";

                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>";
                        echo $row['BOOKING_ID'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NAME'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['SURNAME'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NameOfItems'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['NumberOfItems'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['Amount'];
                        echo "</td>";
                        echo "<td>";
                        echo ($row['NumberOfItems'] * $row['Amount']);
                        echo "</td>";
                        echo "<td>";
                        $discount = $row['DISCOUNT'];
                        if ($row['DISCOUNT_AS'] == '%') {
                            $discount = (($row['Amount'] * $row['NumberOfItems']) * ($row['DISCOUNT']) / 100);
                        }
                        echo $row['DISCOUNT'];
                        echo $row['DISCOUNT_AS'];
                        echo "</td>";
                        echo "<td>";
                        echo ($row['Amount'] * $row['NumberOfItems'] - $discount);
                        echo "</td>";
                        echo "<td>";
                        echo $row['TAX'];
                        echo "</td>";
                        echo "<td>";
                        echo (($row['Amount'] * $row['NumberOfItems'] - $discount) * ($row['TAX']) / 100);       //Total TAX
                        echo "</td>";
                        echo "<td>";
                        echo round(($row['Amount'] * $row['NumberOfItems'] - $discount) + (($row['Amount'] * $row['NumberOfItems'] - $discount) * ($row['TAX']) / 100),2);
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "";
                }
                $conn->close();

                ?>
            </table>
       
       </div>
    </body>
</html>