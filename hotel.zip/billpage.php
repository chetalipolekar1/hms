<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />

    <style>
        input[type=text] {
            background: transparent;
            border: none;
            border-bottom: 1px solid #000000;
            width: 100%;
        }
    </style>
</head>

<body style="margin:29px;border: 1px solid;background-color:white">
    <div style="margin:29px;">
        <?php
        include_once dirname(__FILE__) . './dbDetails.php';
        $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

        if ($conn->connect_error) {
            die("connection failed :" . $conn->connect_error);
        }
        $sql = "SELECT * FROM hoteldetail";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {

                $hotelname = $row['HOTEL_NAME'];
                $detail = $row['DETAIL'];
                $address = $row['ADDRESS'];
                $email = $row['EMAIL'];
                $web = $row['WEBSITE'];
                $contact = $row['CONTACT'];
                $othercontact = $row['OTHER_CONTACT'];
                $newlogonamee = $row['HOTEL_LOGO'];
                $regno = $row['REG_NO'];
                $fsregno = $row['FSREG_NO'];
            }
        }


        $conn->close();

        ?>


        <div>

            <div style="float:left;">
                <p><?php echo "<img src='./images/" . $newlogonamee . "' height='100px' width='100px' />"; ?></p>
            </div>
            <div style="float:right;width: 50%;">

                <b style="text-transform: capitalize;"><?php echo $detail; ?></b>
                <h1 style="font-size:44px;text-transform: capitalize;"><?php echo $hotelname; ?></h1>
                <p style="text-transform: capitalize;"><?php echo $address; ?></p>
                <div>
                    <div style="float:left;"> Date</div>
                    <div style="float:right;width:84% ;"><?php date_default_timezone_set('Asia/Kolkata');
                                                            echo date('d-m-y h:i:sa'); ?></div>
                </div>
            </div>

            <div style="float:left">
                <p><?php echo $contact; ?>
                    </br><?php echo $othercontact; ?></p>
                <p><?php echo $email; ?>
                    </br><?php echo $web; ?></p>


            </div>
        </div>
        </br>
        <div>
            </br>
            </br>
            </br>
            </br>
            </br>
            </br>
            </br>
            </br>
            </br>
            </br>
            <?php
            include_once dirname(__FILE__) . './dbDetails.php';
            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }
            $sql = "SELECT * FROM booking_details where BOOKING_ID=" . $_GET['bookingid'];

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {
                    $newDate = strtotime($row['CHECK_IN']);
                    $check = date("d-m-y h:i:sa", $newDate);

                    $newDate = strtotime($row['CHECK_OUT']);
                    $out = date("d-m-y h:i:sa", $newDate);

                    $roomtype = $row['ROOM_TYPE'];
                    $guestid = $row['GUEST_ID'];
                }
            }
            $sql = "SELECT * FROM guest_details where GUEST_ID=" . $guestid;
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {
                    $guestaddress = $row['ADDRESS'];
                }
            }
            $conn->close();

            ?>
            </br>
            </br>
            <div>
                <div style="float:left;"> Bill No. :</div>
                <div style="float:left;"><?php echo $_GET['billid']; ?></div>
            </div>
            </br>
            <div>
                <div style="float:left;"> Name :</div>
                <div style="float:left;"><?php echo $_GET['username'] . " " . $_GET['surname']; ?></div>
            </div>
            </br>
            <div>
                <div style="float:left;">Address :</div>
                <div style="float:left;"><?php echo $guestaddress; ?></div>
            </div>
            </br>
            <div>
                <div style="float:left;">Room No. :</div>
                <div style="float:left;"><?php echo $_GET['roomno']; ?></div>
            </div>
            </br>
            <div>
                <div style="float:left;"> Arrival (Date & Time) :</div>
                <div style="float:left;"><?php echo $check; ?></div>
            </div>
            </br>
            <div>
                <div style="float:left;"> Departure (Date & Time) :</div>
                <div style="float:left;"><?php echo $out; ?></div>
            </div>
            </br>
        </div>


        </br>
        </br>

        <table style="width:100%;">
            <tr>
                <th>Description</th>
                <th>Qty</th>
                <th>Rate</th>
                <th>Amount</th>
                <th>Discount</th>
                <th>Net Amount</th>
                <th>Tax Rate</th>
                <th>Tax Amount</th>
                <th>Total Amount</th>
            </tr>
            <?php                                                       // select from table
            include_once dirname(__FILE__) . './dbDetails.php';

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }
            $sql = "SELECT * from billing where  BOOKING_ID = " . $_GET['bookingid'];

            $result = $conn->query($sql);
            $totalTax1 = 0;
            $totalTax2 = 0;
            $total1 = 0;
            $total2 = 0;
            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {

                    $paid=$row['PAID'];
                    echo "<tr><td>";
                    echo $roomtype . " " . "Room";
                    echo "</td>";
                    echo "<td>";
                    echo $row['NO_OF_DAYS'];
                    echo "</td>";
                    echo "<td>";
                    echo $row['RENT'];
                    echo "</td>";
                    echo "<td>";
                    echo $row['NO_OF_DAYS'] * $row['RENT'];    //Total Rent
                    echo "</td>";
                    echo "<td>";
                    $discount = $row['DISCOUNT'];
                    if ($row['DISCOUNT_AS'] == '%') {
                        $discount = (($row['RENT'] * $row['NO_OF_DAYS']) * ($row['DISCOUNT']) / 100);
                    }
                    echo $row['DISCOUNT'];
                    echo $row['DISCOUNT_AS'];
                    echo "</td>";
                    echo "<td>";
                    $netAmt = ($row['RENT'] * $row['NO_OF_DAYS'] - $discount);
                    echo $netAmt;
                    echo "</td>";
                    echo "<td>";
                    echo $row['TAX'];
                    echo "</td>";
                    echo "<td>";
                    $totalTax = ($row['TAX_AMOUNT']);
                    echo $totalTax;       //Total TAX
                    $totalTax1 += $totalTax;
                    echo "</td>";
                    echo "<td>";
                    $totalAmmount = $netAmt + $totalTax;
                    echo $totalAmmount;
                    $total1 += $totalAmmount;
                    echo "</td>";
                    echo "</tr>";
                }

                $sql = "SELECT * FROM orderitem where BOOKING_ID=" . $_GET['bookingid'];

                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>";
                        echo $row['NameOfItems'];
                        echo "</td>";
                        echo "<td>";
                        echo  $row['NumberOfItems'];
                        echo "</td>";
                        echo "<td>";
                        echo  $row['Amount'];
                        echo "</td>";
                        echo "<td>";
                        echo ($row['NumberOfItems'] * $row['Amount']);
                        echo "</td>";
                        echo "<td>";
                        $discount = $row['DISCOUNT'];
                        if ($row['DISCOUNT_AS'] == '%') {
                            $discount = (($row['Amount'] * $row['NumberOfItems']) * ($row['DISCOUNT']) / 100);
                        }
                        echo $row['DISCOUNT'];
                        echo $row['DISCOUNT_AS'];
                        echo "</td>";
                        echo "<td>";
                        echo ($row['Amount'] * $row['NumberOfItems'] - $discount);
                        echo "</td>";
                        echo "<td>";
                        echo $row['TAX'];
                        echo "</td>";
                        echo "<td>";
                        $totalTax = ($row['TAX_AMOUNT']);
                        echo  $totalTax;     //Total TAX
                        $totalTax2 += $totalTax;
                        echo "</td>";
                        echo "<td>";
                        $orderTotal = round($row['NET_AMOUNT'], 2);
                        echo  $orderTotal;
                        $total2 += $orderTotal;
                        echo "</td>";
                        echo "</tr>";
                    }
                }
            }
            $conn->close();
            ?>

            <tr>
                <td colspan="7" style="text-align:left;font-weight:bold">Total </td>
                <td><?php echo ($totalTax1 + $totalTax2) . "₹"; ?></td>
                <td><?php echo ($total1 + $total2) . "₹"; ?></td>
            </tr>
            <tr>
                <td  colspan="8" style="text-align:left;font-weight:bold">Remaining </td>
                <td><?php echo ($total1 + $total2)-$paid; ?></td>
            </tr>
        </table>
        <p>E.&O.E.</p>
      
        <div style="float:right">
            <div style="float:left;margin-top: 6px;">
                <p>for-
            </div>
            <div style="float:right">
                <h1 style="font-size:25px;text-transform: capitalize;"><?php echo $hotelname; ?></h1>
                </p>
            </div>
        </div>
    </div>
    <div>
        <b>Note :</b>
        <p>1. This bill is to be paid immediately on presentation.
            </br>2. Part of the day will be reckoned as full day.
            </br>3. Check out time 11:00 Am</p>
    </div>
    </br>

    <div>
        <div style="float:left">Guest Signature</div>

        <div style="float:right">Prop./Manager</div>
    </div>
    </br>
    <hr>
    <p style="text-align: center;"><b>PLEASE LEAVE THE KEY AT RECEPTION</b></p>
    <hr>
    <div>
        <?php
        if ($regno != NULL && $regno != '') {
            echo "Registration No. " . $regno;
        }
        if ($fsregno != NULL && $fsregno != '') {
            echo ", FS&S Registration No. " . $fsregno;
        }
        ?>
    </div>
  
<p style="text-align:center">This is a Computer Generated Invoice</p>
    <button onclick="printbill()" style="float:right">Print </button>

    <script>
        function printbill() {
            window.print();
        }
    </script>
</body>

</html>