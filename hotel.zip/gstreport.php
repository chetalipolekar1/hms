<!DOCTYPE html>
<html>

<head>
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />


</head>

<body>
    <div class="container">
    



        <div>
            <div style="float:center;">
                <div>
                    </br>
                    </br>
                    <form action="./gstreport.php">
                        <select name="year" onchange="this.form.submit()">
                            <option>Select year</option>
                            <?php
                            include_once dirname(__FILE__) . './dbDetails.php';

                            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                            if ($conn->connect_error) {
                                die("connection failed :" . $conn->connect_error);
                            }
                            $sql = "SELECT DISTINCT EXTRACT(YEAR FROM date) AS YEAR FROM billing";

                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                // output data of each row
                                while ($row = $result->fetch_assoc()) {

                                    echo '<option value="' . $row['YEAR'] . '">' . $row['YEAR'] . '</option>';
                                }
                            } else {
                                echo "No Years.";
                            }
                            $conn->close();
                            ?>
                        </select>
                    </form>
                </div>

             
            </div>

            <div style="float:center">

                </br>
                </br>
                </br>

                <div>

                    <table class="tbl" class="table" id="GSTTABLE">
                        <tr>
                            <th>Details</th>
                            <th>Total GST Amount</th>
                            <th>Month</th>
                        </tr>

                        <?php                                                       // select from table
                        include_once dirname(__FILE__) . './dbDetails.php';

                        $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                        if ($conn->connect_error) {
                            die("connection failed :" . $conn->connect_error);
                        }
                        $y = isset($_GET['year']) ? $_GET['year'] : date("Y");
                        $sql = "SELECT SUM(TAX_AMOUNT) AS Total_GSTAMOUNT, EXTRACT(MONTH FROM date) AS MONTH, EXTRACT(YEAR FROM date) AS YEAR FROM billing WHERE year(date) = $y GROUP BY month(date)";

                        $result = $conn->query($sql);
                        $totalGst = 0;
                        if ($result->num_rows > 0) {
                            // output data of each row
                            while ($row = $result->fetch_assoc()) {
                                $totalGst += $row['Total_GSTAMOUNT'];
                                echo "<tr id='select'><td>GST (Rent)</td><td>";
                                echo $row['Total_GSTAMOUNT'];
                                echo "</td>";
                                echo "<td>";
                                echo getMonth($row['MONTH']) . " -" . $row['YEAR'];
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "No entry added.";
                        }
                        //$conn->close();

                        $sql = "SELECT SUM(TAX_AMOUNT) AS Total_GSTAMOUNT , EXTRACT(MONTH FROM date) AS MONTH, EXTRACT(YEAR FROM date) AS YEAR from orderitem GROUP BY month(date)";

                        $result = $conn->query($sql);
                        $totalGst = 0;
                        if ($result->num_rows > 0) {
                            // output data of each row
                            while ($row = $result->fetch_assoc()) {
                                $totalGst += $row['Total_GSTAMOUNT'];
                                echo "<tr id='select'><td>GST (Order)</td><td>";
                                echo $row['Total_GSTAMOUNT'];
                                echo "</td>";
                                echo "<td>";
                                echo getMonth($row['MONTH']) . " -" . $row['YEAR'];
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo " Empty";
                        }
                        $conn->close();


                        function getMonth($number)
                        {
    
                            if ($number == 1) {
                                return "Jan";
                            } else if ($number == 2) {
                                return "Feb";
                            } else if ($number == 3) {
                                return "Mar";
                            } else if ($number == 4) {
                                return "Apr";
                            } else if ($number == 5) {
                                return "May";
                            } else if ($number == 6) {
                                return "Jun";
                            } else if ($number == 7) {
                                return "Jul";
                            } else if ($number == 8) {
                                return "Aug";
                            } else if ($number == 9) {
                                return "Sep";
                            } else if ($number == 10) {
                                return "Oct";
                            } else if ($number == 11) {
                                return "Nov";
                            } else if ($number == 12) {
                                return "Dec";
                            }
                        }

                        ?>
                    </table>

                </div>

            </div>
        </div>



    <button onclick="sortTable()">Sort</button>
  
    </div>
<script>

function getMonthNumber(monthName) {

    
    if(monthName == "May") {
        return 5;
    } else if(monthName == "Jun") {
        return 6;
    }
}
function sortTable() {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("GSTTABLE");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[2];
      y = rows[i + 1].getElementsByTagName("TD")[2];
      //check if the two rows should switch place:
      if (getMonthNumber(x.innerHTML.split(" ")[0]) > getMonthNumber(y.innerHTML.split(" ")[0])) {
        //if so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}
</script>
</body>


</html>