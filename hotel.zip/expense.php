<!DOCTYPE html>
<html>

<head>
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />

    <!--
<script>
    
    var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();

today = dd + '-' + mm + '-' + yyyy;
document.write(today);
    </script>
-->
</head>

<body>
    <div>
        <?php

        include_once dirname(__FILE__) . './dbDetails.php';

        //Update
        if (isset($_POST['expenseid']) && $_POST['expenseid'] != '') {
            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);


            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "UPDATE expense SET DESCRIPTION='" . $_POST['discription'] . "', DATE='" . $_POST['date'] . "', AMOUNT ='" . $_POST['amount'] . "' WHERE EXP_ID = " . $_POST['expenseid'];

            //update value
            if ($conn->query($sql) === TRUE) {

                echo "Updated successfully";
            } else {
                echo "Error: " . "<br>" . $conn->error;
            }
            $conn->close();
        } else if (isset($_POST['date'])) {                   //code to display bill

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);  //create conncetion

            if ($conn->connect_error)                              //check connection
            {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "INSERT INTO expense(DATE,DESCRIPTION,DETAIL,AMOUNT) VALUES('" . $_POST['date'] . "','" . $_POST['discription'] . "','" . $_POST['detail'] . "'," . $_POST['amount'] . ")";

            //insert value
            if ($conn->query($sql) === TRUE) {

                echo " added successfully";
            } else {
                echo "Error: ". "<br>" . $conn->error;
            }
            $conn->close();
        }

        //code to delete 
        if (isset($_GET['deleteexpenseid'])) {

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "DELETE FROM expense WHERE EXP_ID = " . $_GET['deleteexpenseid'];

            if ($conn->query($sql) === TRUE) {
                echo  " deleted succesfully.";
            } else {
                echo "Error deleting name" . $conn->error;
            }
            $conn->close();
        }



        ?>


        <form action="./expense.php" method="POST">

            <fieldset>
                <legend>Billing Details :</legend>
                <div>
                    <div>
                        <input type="hidden" name="expenseid" value="<?php if (isset($_GET['expenseid'])) echo $_GET['expenseid'] ?>" />
                    </div>

                    <input type="text" name="discription" placeholder="Discription" value="<?php if (isset($_GET['discription'])) echo $_GET['discription'] ?>" />

                    <input type="text" name="detail" placeholder="Detail" value="<?php if (isset($_GET['detail'])) echo $_GET['detail'] ?>" />


                    <div>
                        <input type="date" name="date" value="<?php if (isset($_GET['date'])) {
                                                                    echo date('Y-m-d', strtotime($_GET['date']));
                                                                } else {
                                                                    echo date('Y-m-d');
                                                                }
                                                                ?>" />
                    </div>

                    <div>

                        <input placeholder="Amount" type="text" name="amount" value="<?php if (isset($_GET['amount'])) echo $_GET['amount'] ?>" />
                    </div>


                    <div>
                        <input type="submit" class="btn1"></input>

                    </div>
                </div>
            </fieldset>
        </form>

    </div>
    <div style="float:center;">


        <table class="tbl">
            <tr>


                <th>DATE</th>
                <th>DESCRIPTION</th>
                <th>DETAIL</th>
                <th>AMOUNT</th>
                <th>Active</th>
            </tr>

            <?php                                                       // select from table
            include_once dirname(__FILE__) . './dbDetails.php';

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }
            $sql = "SELECT `EXP_ID`, `DATE`, `DESCRIPTION`,`DETAIL`, SUM(`AMOUNT`) AS `AMOUNT` FROM `expense` GROUP BY `DESCRIPTION` ORDER BY `EXP_ID`";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {


                    echo "<tr><td>"; 
                    $newDate = strtotime($row['DATE']);
                    echo date("d-m-y", $newDate);               
                    echo "</td>";
                    echo "<td> <a href='./expdetail.php?description=".$row['DESCRIPTION']."'>";
                    echo $row['DESCRIPTION'];
                    echo "</a></td>";
                    echo "<td>";
                    echo $row['DETAIL'];
                    echo "</td>";
                    echo "<td>";
                    echo $row['AMOUNT'];
                    echo "</td>";
                    echo "<td><span style='float: left;'><a class='onicon' href='./expense.php?expenseid=" . $row['EXP_ID'] . "&discription=" . $row['DESCRIPTION'] . "&detail=" . $row['DETAIL'] . "&date=" . $row['DATE'] . "&amount=" . $row['AMOUNT'] . "'>";
                    echo "<i class='fa fa-pencil-alt'></i></a></span>";
                    echo "<span style='float: right;'><a class='actionicon' href='./expense.php?deleteexpenseid=" . $row['EXP_ID'] . "'>";
                    echo "<i class='fa fa-trash-alt'></i></a></span>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "Empty ";
            }

            $conn->close();
            ?>
        </table>

    </div>

</body>


</html>