<html>

<body>
    <style>
        #myProgress {
            width: 100%;
            background-color: #ddd;
        }

        #myBar {
            width: 5%;
            height: 30px;
            background-color: blue;
            text-align: center;
            line-height: 30px;
            color: white;
        }
    </style>
    <script>
        var i = 0;

        function move() {
            if (i == 0) {
                i = 1;
                var elem = document.getElementById("myBar");
                var width = 1;
                var id = setInterval(frame, 30);

                function frame() {
                    if (width >= 100) {
                        clearInterval(id);
                        i = 0;
                    } else {
                        width++;
                        elem.style.width = width + "%";
                        elem.innerHTML = width + "%";
                    }
                }
            }
        }
    </script>

    <div style="margin:210px">
        <h2>Installing hotel management software.</h2>
        <div id="myProgress">
            <div id="myBar"></div>
        </div>

        <br>
        <br>
        <br>
        <br>
        <button onclick="move()" style="float:right">Install</button>

    </div>
    <?php

    $sqlCreateDb = "CREATE DATABASE hotel";

    $sqlCreateBilling = "CREATE TABLE `billing` (
    `BOOKING_ID` bigint(20) DEFAULT NULL,
    `ROOM_NO` int(11) DEFAULT NULL,
    `NAME` varchar(50) DEFAULT NULL,
    `SURNAME` varchar(50) DEFAULT NULL,
    `NO_OF_DAYS` int(11) DEFAULT NULL,
    `RENT` double(19,2) DEFAULT NULL,
    `DISCOUNT` double(19,2) DEFAULT NULL,
    `DISCOUNT_AS` varchar(5) NOT NULL DEFAULT '%',
    `TAX` double(19,2) DEFAULT NULL,
    `TAX_AMOUNT` double(19,2) DEFAULT NULL,
    `NET_AMOUNT` double(19,2) NOT NULL,
    `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `PAYMENT_METHOD` varchar(50) DEFAULT NULL,
    `PAID` double DEFAULT NULL,
    `BILL_ID` bigint(20) NOT NULL
  )";


    $sqlBillingAlter1 = "ALTER TABLE `billing`
 ADD PRIMARY KEY (`BILL_ID`),
 ADD KEY `BOOKINF_ID` (`BOOKING_ID`);";


    $sqlBillingAlter2 = "ALTER TABLE `billing`
MODIFY `BILL_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;";

    $sqlCreateBookingdetails = "CREATE TABLE `booking_details` (
    `BOOKING_ID` bigint(11) NOT NULL,
    `GUEST_ID` bigint(11) NOT NULL,
    `NAME` varchar(50) DEFAULT NULL,
    `SURNAME` varchar(50) DEFAULT NULL,
    `ROOM_NO` int(11) DEFAULT NULL,
    `ROOM_TYPE` varchar(50) DEFAULT NULL,
    `NO_OF_DAYS` int(11) DEFAULT NULL,
    `NO_OF_MEMBERS` int(11) DEFAULT NULL,
    `BED` varchar(20) DEFAULT NULL,
    `CHECK_IN` datetime(6) DEFAULT NULL,
    `CHECK_OUT` datetime(6) DEFAULT NULL
  )";

    $sqlBookingdetailsAlter1 = "ALTER TABLE `guest_details`
  ADD PRIMARY KEY (`GUEST_ID`),
  ADD KEY `GUEST_ID` (`GUEST_ID`),
  ADD KEY `GUEST_ID_2` (`GUEST_ID`);";

    $sqlBookingdetailsAlter2 = "ALTER TABLE `booking_details`
  MODIFY `BOOKING_ID` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;";

    $sqlCreateCform = "CREATE TABLE `cform` (
    `GUEST_ID` bigint(11) NOT NULL,
    `CITY` varchar(50) DEFAULT NULL,
    `PASSPORT_NO` varchar(50) DEFAULT NULL,
    `PASS_CITY` varchar(50) DEFAULT NULL,
    `PASS_COUNTRY` varchar(50) DEFAULT NULL,
    `PASS_DATE` date DEFAULT NULL,
    `VALID_DATE` date DEFAULT NULL,
    `VISA` varchar(50) DEFAULT NULL,
    `VISA_CITY` varchar(50) DEFAULT NULL,
    `VISA_COUNTRY` varchar(50) DEFAULT NULL,
    `VISA_DATE` date DEFAULT NULL,
    `VISA_VALID_DATE` date DEFAULT NULL,
    `VISA_TYPE` varchar(50) DEFAULT NULL,
    `VISA_SUBTYPE` varchar(50) DEFAULT NULL,
    `ARRIVE_COUNTRY` varchar(50) DEFAULT NULL,
    `ARRIVE_CITY` varchar(50) DEFAULT NULL,
    `DATE_ARRIVE_INDIA` date DEFAULT NULL,
    `DATE_ARRIVE_HOTEL` date DEFAULT NULL,
    `TIME_IN_HOTEL` time DEFAULT NULL,
    `EMPLOYED_IN_INDIA` varchar(50) DEFAULT NULL,
    `NEXT_DEST` varchar(50) DEFAULT NULL,
    `DEST_STATE` varchar(50) DEFAULT NULL,
    `DEST_CITY` varchar(50) DEFAULT NULL,
    `DEST_PLACE` varchar(50) DEFAULT NULL,
    `CONTACT_INDIA` bigint(11) DEFAULT NULL,
    `MOBILE_INDIA` bigint(20) DEFAULT NULL,
    `CONTACT_COUNTRY` bigint(20) DEFAULT NULL,
    `MOBILE_COUNTRY` bigint(20) DEFAULT NULL,
    `REMARK` varchar(100) DEFAULT NULL
  )";

    $sqlCformAlter = "ALTER TABLE `cform`
  ADD KEY `GUEST_ID` (`GUEST_ID`);";

    $sqlCreateGuestdetails = "CREATE TABLE `guest_details` (
    `IMAGE` text,
    `ID_IMAGE` text,
    `GUEST_ID` int(11) NOT NULL,
    `NAME` varchar(50) DEFAULT NULL,
    `SURNAME` varchar(50) DEFAULT NULL,
    `GENDER` varchar(10) DEFAULT NULL,
    `AGE` int(11) DEFAULT NULL,
    `DOB` date DEFAULT NULL,
    `ADDRESS` varchar(100) DEFAULT NULL,
    `PINCODE` int(11) DEFAULT NULL,
    `STATE` varchar(50) DEFAULT NULL,
    `COUNTRY` varchar(50) DEFAULT NULL,
    `NATIONALITY` varchar(50) DEFAULT NULL,
    `SPECIAL_CATEGORY` varchar(50) DEFAULT NULL,
    `CONTACT_NO` bigint(13) DEFAULT NULL,
    `EMAIL` varchar(50) DEFAULT NULL,
    `ID_PROOF` varchar(60) DEFAULT NULL,
    `MARITAL_STATUS` varchar(10) DEFAULT NULL,
    `ID_PROOF_NO` varchar(50) DEFAULT NULL,
    `FROMCITY` varchar(50) DEFAULT NULL,
    `TOCITY` varchar(50) DEFAULT NULL,
    `TRAVELMEDIUM` varchar(50) DEFAULT NULL,
    `TRAVELNO` varchar(256) DEFAULT NULL,
    `VISIT_PURPOSE` varchar(256) DEFAULT NULL
  )";

    $sqlGuestdetailsAlter1 = "ALTER TABLE `guest_details`
  ADD PRIMARY KEY (`GUEST_ID`),
  ADD KEY `GUEST_ID` (`GUEST_ID`),
  ADD KEY `GUEST_ID_2` (`GUEST_ID`);";

    $sqlGuestdetailsAlter2 = "ALTER TABLE `guest_details`
  MODIFY `GUEST_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;";

    $sqlCreateExpense = "CREATE TABLE `expense` (
    `EXP_ID` bigint(11) NOT NULL,
    `DATE` date DEFAULT NULL,
    `DESCRIPTION` varchar(256) NOT NULL,
    `DETAIL` varchar(256) DEFAULT NULL,
    `AMOUNT` int(11) DEFAULT NULL
  )";

    $sqlExpenseAlter1 = "ALTER TABLE `expense`
  ADD PRIMARY KEY (`EXP_ID`);";

    $sqlExpenseAlter2 = "ALTER TABLE `expense`
  MODIFY `EXP_ID` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;";

    $sqlCreateHoteldetail = "CREATE TABLE `hoteldetail` (
    `id` int(11) NOT NULL,
    `DETAIL` varchar(256) DEFAULT NULL,
    `HOTEL_NAME` varchar(256) DEFAULT NULL,
    `ADDRESS` varchar(256) DEFAULT NULL,
    `CONTACT` varchar(256) DEFAULT NULL,
    `OTHER_CONTACT` varchar(256) DEFAULT NULL,
    `EMAIL` varchar(256) DEFAULT NULL,
    `HOTEL_LOGO` varchar(256) DEFAULT NULL,
    `WEBSITE` varchar(256) DEFAULT NULL,
    `REG_NO` bigint(20) DEFAULT NULL,
    `FSREG_NO` bigint(20) DEFAULT NULL
  )";

    $sqlCreateOrderitem = "CREATE TABLE `orderitem` (
    `BOOKING_ID` bigint(20) DEFAULT NULL,
    `NAME` varchar(50) DEFAULT NULL,
    `SURNAME` varchar(50) DEFAULT NULL,
    `NameOfItems` varchar(40) DEFAULT NULL,
    `NumberOfItems` double(19,2) DEFAULT NULL,
    `Amount` int(11) DEFAULT NULL,
    `DISCOUNT` double(19,2) DEFAULT NULL,
    `DISCOUNT_AS` varchar(5) NOT NULL DEFAULT '%',
    `TAX` double(19,2) DEFAULT NULL,
    `TAX_AMOUNT` double(19,2) DEFAULT NULL,
    `NET_AMOUNT` double(19,2) NOT NULL DEFAULT '0.00',
    `ID` bigint(20) NOT NULL,
    `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  )";

    $sqlOrderitemAlter1 = "ALTER TABLE `orderitem`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `GUEST_ID` (`BOOKING_ID`);";

    $sqlOrderitemAlter2 = "ALTER TABLE `orderitem`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;";

    $sqlCreateRoom = "CREATE TABLE `room` (
    `ROOM_NO` int(11) NOT NULL,
    `ROOM_TYPE` varchar(50) NOT NULL
  )";

    $sqlRoomAlter = "ALTER TABLE `room`
  ADD PRIMARY KEY (`ROOM_NO`);";


    include_once dirname(__FILE__) . './dbDetails.php';
    $conn = new mysqli(dbhost, dbusername, dbpass);
    if ($conn->connect_error) {
        die("connection failed :" . $conn->connect_error);
    }
    $conn->query($sqlCreateDb);
    $conn->close();

    $conn = new mysqli(dbhost, dbusername, dbpass, "hotel");    //need to change

    if ($conn->connect_error) {
        die("connection failed :" . $conn->connect_error);
    }

    $conn->query($sqlCreateBilling);
    $conn->query($sqlBillingAlter1);
    $conn->query($sqlBillingAlter2);
    $conn->query($sqlCreateBookingdetails);
    $conn->query($sqlBookingdetailsAlter1);
    $conn->query($sqlBookingdetailsAlter1);
    $conn->query($sqlCreateCform);
    $conn->query($sqlCformAlter);
    $conn->query($sqlCreateGuestdetails);
    $conn->query($sqlGuestdetailsAlter1);
    $conn->query($sqlGuestdetailsAlter2);
    $conn->query($sqlCreateExpense);
    $conn->query($sqlExpenseAlter1);
    $conn->query($sqlExpenseAlter2);
    $conn->query($sqlCreateHoteldetail);
    $conn->query($sqlCreateOrderitem);
    $conn->query($sqlOrderitemAlter1);
    $conn->query($sqlOrderitemAlter2);
    $conn->query($sqlCreateRoom);
    $conn->query($sqlRoomAlter);



    $sqlinsertHotelPlaceholder = "INSERT INTO hoteldetail (id, DETAIL, HOTEL_NAME, ADDRESS, CONTACT, OTHER_CONTACT, EMAIL, HOTEL_LOGO, WEBSITE, REG_NO, FSREG_NO) VALUES (1, 'Hotel Detail', 'Hotel Name', 'Address', 'Contact No.', 'Contact No.(Other)', 'E-mail', 'Hotel logo', 'Hotel Website', null,null)";



    $conn->query($sqlinsertHotelPlaceholder);


    $conn->close();
    ?>