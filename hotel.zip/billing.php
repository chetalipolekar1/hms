<!DOCTYPE html>
<html>

<head>
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />

</head>

<body>
    <div>
        <?php

        include_once dirname(__FILE__) . './dbDetails.php';

        //Update
        if (isset($_POST['billid']) && $_POST['billid'] != '') {
            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);


            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "UPDATE billing SET PAID = PAID + " . $_POST['paid'] . ", NAME='" . $_POST['username'] . "',SURNAME='" . $_POST['surname'] . "', ROOM_NO=" . $_POST['roomno'] . ", RENT =" . $_POST['roomrent'] . ", NO_OF_DAYS=" . $_POST['day'] . ", DISCOUNT=" . $_POST['discount'] . ",DISCOUNT_AS='" . $_POST['discountAs'] . "',TAX=" . $_POST['tax'] . ",TAX_AMOUNT=" . $_POST['taxamount'] . ", date='" . $_POST['date'] . "', PAYMENT_METHOD='" . $_POST['method'] . "',NET_AMOUNT=" . $_POST['net'] . " WHERE BILL_ID = " . $_POST['billid'];

            //update value
            if ($conn->query($sql) === TRUE) {

                echo "Updated successfully";
            } else {
                echo "Error: "  . "<br>" . $conn->error;
            }
            $conn->close();
        } else if (isset($_POST['day'])) {                   //code to display bill

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);  //create conncetion

            if ($conn->connect_error)                              //check connection
            {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "INSERT INTO billing(BOOKING_ID,ROOM_NO,NAME,SURNAME ,NO_OF_DAYS,RENT,DISCOUNT,DISCOUNT_AS, TAX, TAX_AMOUNT,NET_AMOUNT,date,PAYMENT_METHOD,PAID) VALUES(" . $_POST['bookingid'] . "," . $_POST['roomno'] . ",'" . $_POST['username'] . "','" . $_POST['surname'] . "'," . $_POST['day'] . "," . $_POST['roomrent'] . "," . $_POST['discount'] . ",'" . $_POST['discountAs'] . "'," . $_POST['tax'] . "," . $_POST['taxamount'] . "," . $_POST['net'] . ",'" . $_POST['date'] . "','" . $_POST['method'] . "'," . $_POST['paid'] . ")";

            //insert value
            if ($conn->query($sql) === TRUE) {

                echo " added successfully";
            } else {
                echo "Error: " . "<br>" . $conn->error;
            }
            $conn->close();
        }

        //code to delete 
        if (isset($_GET['deletebillid'])) {

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }

            $sql = "DELETE FROM billing WHERE BILL_ID = " . $_GET['deletebillid'];

            if ($conn->query($sql) === TRUE) {
                echo  " deleted succesfully.";
            } else {
                echo "Error deleting name" . $conn->error;
            }
            $conn->close();
        }



        ?>


        <form action="./billing.php" method="POST">

            <fieldset>
                <legend>Billing Details :</legend>
                <div>
                    <div>
                        <input type="hidden" name="billid" value="<?php if (isset($_GET['billid'])) echo $_GET['billid'] ?>" />
                        <input placeholder="Booking id" name="bookingid" value="<?php if (isset($_GET['bookingid'])) echo $_GET['bookingid'] ?>" />
                    </div>
                    <div>

                        <input placeholder="Room Number" type="number" name="roomno" value="<?php if (isset($_GET['roomno'])) echo $_GET['roomno'] ?>" />
                    </div>
                    <input type="text" name="username" placeholder="Name" maxlength="30" value="<?php if (isset($_GET['username'])) echo $_GET['username'] ?>" />

                    <div>
                        <div>

                            <input type="text" name="surname" placeholder="Surname" maxlength="30" value="<?php if (isset($_GET['surname'])) echo $_GET['surname'] ?>" />
                        </div>
                        <input placeholder="No. Of Days" id="day" name="day" value="<?php if (isset($_GET['day'])) echo $_GET['day'] ?>" />
                    </div>
                    <div>

                        <input placeholder="Room Rent" type="text" id="rent" name="roomrent" min="0" value="<?php if (isset($_GET['roomrent'])) echo $_GET['roomrent'] ?>" onchange="updateTax()" />
                    </div>
                    <div>
                        <div style="float:left;width:23%;">
                            <label>Discount :</label>

                        </div>

                        <div style="float:left;width:58.5%;">

                            <input type="text" id="calc" name="discount" onchange="calculateTotalGSTAmount()" value="<?php if (isset($_GET['discount'])) echo $_GET['discount'] ?>" />
                        </div>
                        <div style="float:left;width:18.5%;" onclick="calDiscount()">
                            <input type="text" style="background-color: #346d9e;color: #000000;margin-top: 4.5px;;font-weight:bold;font-size:large;border:none;height:18px;border: 1px solid;border-radius: 4px;" readonly id="discountAs" name="discountAs" value="<?php if (isset($_GET['discountAs'])) {
                                                                                                                                                                                                                                                                        echo $_GET['discountAs'];
                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                        echo "%";
                                                                                                                                                                                                                                                                    }

                                                                                                                                                                                                                                                                    ?>">
                        </div>
                    </div>

                    <div>
                        <div style="float:left;">
                            <label>GST-Tax :</label>

                        </div>
                        <div style="float:right;width:81.5%;">
                            <input type="text" id="tax" name="tax" value="<?php if (isset($_GET['tax'])) echo $_GET['tax'] ?>" />
                        </div>
                    </div>
                    <div>
                        <div style="float:left;">
                            <label>GST-Amount :</label>

                        </div>
                        <div style="float:right;width:81.5%;">
                            <input type="text" id="taxamount" name="taxamount" value="<?php if (isset($_GET['taxamount'])) echo $_GET['taxamount'] ?>" />
                        </div>
                    </div>

                    <div>

                        <input type="date" name="date" value="<?php if (isset($_GET['date'])) {
                                                                    echo date('Y-m-d', strtotime($_GET['date']));
                                                                } else {
                                                                    echo date('Y-m-d');
                                                                }
                                                                ?>" />
                    </div>

                    <div>

                        <input placeholder="Payment Via" type="text" name="method" value="<?php if (isset($_GET['method'])) echo $_GET['method'] ?>" />
                    </div>
                    <div>
                        <div style="float:left;">
                            <label>Total-Amount :</label>
                        </div>
                        <div style="float:right;width:70.5%;">
                            <input type="text" id="totalamount" name="net" value="<?php if (isset($_GET['net'])) echo $_GET['net'] ?>" />
                        </div>

                    </div>
                    <div>

                        <input placeholder="Paid" type="text" name="paid" />
                    </div>


                    <div>
                        <input type="submit" class="btn1"></input>

                    </div>
                </div>
            </fieldset>
        </form>

    </div>
    <div style="float:center;">


        <table class="tbl" class="table" id="comparisonTable">
            <tr>
                <th>Booking Id</th>
                <th>Room No.</th>
                <th>NAME</th>
                <th>Surname</th>
                <th>Payment Date</th>
                <th>No. Of Days</th>
                <th>Room Rent/Day</th>
                <th>Amount</th>
                <th>Discount</th>
                <th>Net-Amount</th>
                <th>GST Rate(%)</th>
                <th>GST Amount</th>
                <th>Total-Amount</th>
                <th>Food Bill(Total-Amount)</th>
                <th>Total Payable(Room+Food)</th>
                <th>Payment Via</th>
                <th>Paid</th>
                <th>Remaining</th>
                <th>Print Bill</th>
                <th>Active</th>
            </tr>

            <?php                                                       // select from table
            include_once dirname(__FILE__) . './dbDetails.php';

            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

            if ($conn->connect_error) {
                die("connection failed :" . $conn->connect_error);
            }
            $sql = "SELECT billing.BILL_ID, billing.BOOKING_ID, billing.ROOM_NO, billing.NAME,billing.SURNAME, billing.NO_OF_DAYS, billing.RENT,billing.DISCOUNT, billing.DISCOUNT_AS, billing.TAX,billing.TAX_AMOUNT, billing.date,billing.NET_AMOUNT, billing.PAYMENT_METHOD, billing.PAID , SUM(IFNULL((orderitem.NET_AMOUNT),0)) AS TOTAL_AMOUNT from billing LEFT OUTER JOIN orderitem ON billing.BOOKING_ID = orderitem.BOOKING_ID GROUP by billing.BOOKING_ID DESC";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {


                    echo "<tr id='select'><td>";
                    echo "<a class='actioicon' href='./order.php?bookingid= " . $row['BOOKING_ID'] . "&username=" . $row['NAME'] . "&surname=" . $row['SURNAME'] . "'>";
                    echo $row['BOOKING_ID'];
                    echo "</a>";
                    echo "</td>";
                    echo "<td>";
                    echo $row['ROOM_NO'];
                    echo "</td>";
                    echo "<td>";
                    echo $row['NAME'];
                    echo "</td>";
                    echo "<td>";
                    echo $row['SURNAME'];
                    echo "</td>";
                    echo "<td>";
                    $newDate = strtotime($row['date']);
                    echo date("d-m-y", $newDate);
                    echo "</td>";
                    echo "<td>";
                    echo $row['NO_OF_DAYS'];
                    echo "</td>";
                    echo "<td>";
                    echo $row['RENT'];
                    echo "</td>";
                    echo "<td>";
                    echo ($row['RENT'] * $row['NO_OF_DAYS']);    //Total Rent
                    echo "</td>";
                    echo "<td>";
                    $discount = $row['DISCOUNT'];
                    if ($row['DISCOUNT_AS'] == '%') {
                        $discount = (($row['RENT'] * $row['NO_OF_DAYS']) * ($row['DISCOUNT']) / 100);
                    }
                    echo $row['DISCOUNT'];
                    echo $row['DISCOUNT_AS'];
                    echo "</td>";
                    echo "<td>";
                    $netAmt = ($row['RENT'] * $row['NO_OF_DAYS'] - $discount);
                    echo $netAmt;
                    echo "</td>";
                    echo "<td>";
                    echo $row['TAX'];
                    echo "</td>";
                    echo "<td>";
                    $totalTax = ($row['TAX_AMOUNT']);
                    echo $totalTax;       //Total TAX
                    echo "</td>";
                    echo "<td>";
                    $totalAmmount = $netAmt + $totalTax;
                    echo $totalAmmount;
                    echo "</td>";
                    echo "<td>";
                    $orderTotal = round($row['TOTAL_AMOUNT'], 2);
                    echo $orderTotal;
                    echo "</td>";
                    echo "<td  class='hoursA'>";
                    $total = $orderTotal + $totalAmmount;
                    echo $total;
                    echo "</td>";          //Total Payable(if order)
                    echo "<td>";
                    $PAID = round($row['PAYMENT_METHOD'], 2);
                    echo  $PAID;
                    echo "</td>";
                    echo "<td class='hoursB'>";
                    echo $row['PAID'];    //Paid
                    echo "</td>";
                    echo "<td class='difference'>";          //Remaining

                    echo round($total - $row['PAID'], 2);
                    echo "</td>";
                    echo "<td><a target='_blank' class='onicon' href='./billpage.php?billid=" . $row['BILL_ID'] . "&date=" . $row['date'] . "&bookingid=" . $row['BOOKING_ID'] . "&roomno=" . $row['ROOM_NO'] . "&surname=" . $row['SURNAME'] . "&net=" . $row['NET_AMOUNT'] . "&username=" . $row['NAME'] . "&day=" . $row['NO_OF_DAYS'] . "&discount=" . $row['DISCOUNT'] . "&discountAs=" . $row['DISCOUNT_AS'] . "&tax=" . $row['TAX'] . "&taxamount=" . $row['TAX_AMOUNT'] . "&roomrent=" . $row['RENT'] . "&method=" . $row['PAYMENT_METHOD'] . "&paid=" . $row['PAID'] . "'>";
                    echo "<i class='fa fa-print'></i></a>";
                    echo "</td>";
                    echo "<td><span style='float: left;'><a class='onicon' href='./billing.php?billid=" . $row['BILL_ID'] . "&bookingid=" . $row['BOOKING_ID'] . "&date=" . $row['date'] . "&roomno=" . $row['ROOM_NO'] . "&surname=" . $row['SURNAME'] . "&net=" . $row['NET_AMOUNT'] . "&username=" . $row['NAME'] . "&day=" . $row['NO_OF_DAYS'] . "&discount=" . $row['DISCOUNT'] . "&discountAs=" . $row['DISCOUNT_AS'] . "&tax=" . $row['TAX'] . "&taxamount=" . $row['TAX_AMOUNT'] . "&roomrent=" . $row['RENT'] . "&method=" . $row['PAYMENT_METHOD'] . "'>";
                    echo "<i class='fa fa-pencil-alt'></i></a></span>";
                    echo "<span style='float: right;'><a class='actionicon' href='./billing.php?deletebillid=" . $row['BILL_ID'] . "'>";
                    echo "<i class='fa fa-trash-alt'></i></a></span>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo " Empty";
            }

            $conn->close();
            ?>
        </table>

    </div>
    <script src="./js/jquery.js"></script>

    <script>
        function compareCellValues() {

            var rows = $("#comparisonTable").find("tr"); //returns all table rows

            rows.each(function() { //iterate over each row.

                var thisRow = $(this), //this is the current row
                    hoursA = thisRow.find(".hoursA"), //this is the first value
                    hoursB = thisRow.find(".hoursB"); //this is the second value

                if (hoursA.text() !== hoursB.text()) {
                    thisRow.css('background-color', '#EC3D3D');
                    thisRow.css('color', '#ffffff');
                    thisRow.find("a").css('color', '#ffffff');
                    thisRow.find("a:hover").css('color', '#EC3D3D');
                }
            });

        }

        window.onload = compareCellValues();

        function updateTax() {
            var roomrent = document.getElementById("rent").value;
            var gsttax = document.getElementById("tax");
            if (roomrent < 1000) {
                gsttax.value = 0
            } else {
                gsttax.value = 12;
            }

        }

        function calculateTotalAmount() {
            var item = document.getElementById("day").value;
            var rate = document.getElementById("rent").value;
            var discount = document.getElementById("calc").value;
            var discountAs = document.getElementById("discountAs").value;
            var tax = document.getElementById("tax").value;
            if (discountAs === '%') {
                var ans = ((item * rate) - item * rate * (discount / 100)) + (item * rate - item * rate * (discount / 100)) * (tax / 100);
            } else {
                var ans = (item * rate - (discount) + (item * rate - discount) * (tax / 100));
            }
            totalamount.value = ans;

        }

        function calculateTotalGSTAmount() {
            var item = document.getElementById("day").value;
            var rate = document.getElementById("rent").value;
            var discount = document.getElementById("calc").value;
            var discountAs = document.getElementById("discountAs").value;
            var tax = document.getElementById("tax").value;
            if (discountAs === '%') {
                var ans = ((item * rate) - (item * rate * (discount / 100))) * (tax / 100);
            } else {
                var ans = (((item * rate) - discount) * (tax / 100));
            }
            taxamount.value = ans;
            calculateTotalAmount()
        }




        window.onload = updateTax();
    </script>
    <script>
        function calDiscount() {
            var x = document.getElementById("discountAs");
            if (x.value == "%") {
                x.value = "₹";
            } else {
                x.value = "%";
            }
            calculateTotalGSTAmount();
        }
    </script>
</body>


</html>