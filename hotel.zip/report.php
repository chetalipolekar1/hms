<!DOCTYPE html>
<html>

<head>
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />


</head>

<body>


<div>

        <div>
            <div style="float:left;width:30%">
                <div>
                    </br>
                    </br>
                    <form action="./report.php">
                        <select name="year" onchange="this.form.submit()">
                            <option>Select year</option>
                            <?php
                            include_once dirname(__FILE__) . './dbDetails.php';

                            $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                            if ($conn->connect_error) {
                                die("connection failed :" . $conn->connect_error);
                            }
                            $sql = "SELECT DISTINCT EXTRACT(YEAR FROM date) AS YEAR FROM billing";

                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                // output data of each row
                                while ($row = $result->fetch_assoc()) {

                                    echo '<option value="' . $row['YEAR'] . '">' . $row['YEAR'] . '</option>';
                                }
                            } else {
                                echo "No Years.";
                            }
                            $conn->close();
                            ?>
                        </select>
                    </form>
                </div>

                <table class="tbl" class="table">
                    <tr>
                        <th>Total Received Payment</th>
                        <th>Month</th>
                    </tr>

                    <?php                                                       // select from table
                    include_once dirname(__FILE__) . './dbDetails.php';

                    $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                    if ($conn->connect_error) {
                        die("connection failed :" . $conn->connect_error);
                    }
                    $y = isset($_GET['year']) ? $_GET['year'] : date("Y");
                    $totalIncome = 0;
                    $sql = "SELECT SUM(PAID) AS Total_Paid, EXTRACT(MONTH FROM date) AS MONTH, EXTRACT(YEAR FROM date) AS YEAR FROM billing WHERE year(date) = $y GROUP BY month(date)";

                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // output data of each row
                        while ($row = $result->fetch_assoc()) {

                            $totalIncome = $totalIncome + $row['Total_Paid'] ;
                            echo "<tr><td>";
                            echo $row['Total_Paid'];
                            echo "</td>";
                            echo "<td>";
                            echo getMonth($row['MONTH']) . "-" . $row['YEAR'];
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "No entry added.";
                    }
                    $conn->close();

                    function getMonth($number)
                    {

                        if ($number == 1) {
                            return "Jan";
                        } else if ($number == 2) {
                            return "Feb";
                        } else if ($number == 3) {
                            return "Mar";
                        } else if ($number == 4) {
                            return "Apr";
                        } else if ($number == 5) {
                            return "May";
                        } else if ($number == 6) {
                            return "Jun";
                        } else if ($number == 7) {
                            return "Jul";
                        } else if ($number == 8) {
                            return "Aug";
                        } else if ($number == 9) {
                            return "Sep";
                        } else if ($number == 10) {
                            return "Oct";
                        } else if ($number == 11) {
                            return "Nov";
                        } else if ($number == 12) {
                            return "Dec";
                        }
                    }
                    ?>
                </table>

            </div>

            <div style="float:right; width:70%;">

                </br>
                </br>
                </br>

                <div>

                    <table class="tbl" class="table">
                        <tr>
                            <th>Description</th>
                            <th>Total Expense</th>
                            <th>Month</th>
                        </tr>

                        <?php                                                       // select from table
                        include_once dirname(__FILE__) . './dbDetails.php';

                        $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                        if ($conn->connect_error) {
                            die("connection failed :" . $conn->connect_error);
                        }
                        $y = isset($_GET['year']) ? $_GET['year'] : date("Y");
                        $sql = "SELECT SUM(AMOUNT) AS Total_AMOUNT, EXTRACT(MONTH FROM date) AS MONTH, EXTRACT(YEAR FROM date) AS YEAR FROM expense WHERE year(date) = $y GROUP BY month(date)";

                        $result = $conn->query($sql);
                        $totalExpense = 0;
                        if ($result->num_rows > 0) {
                            // output data of each row
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr><td>";
                                echo "<a href='./expense.php'>";
                                echo "Hotel";
                                echo "</a></td>";
                                echo "<td>";
                                echo $row['Total_AMOUNT'];
                                $totalExpense += $row['Total_AMOUNT'];
                                echo "</td>";
                                echo "<td>";
                                echo getMonth($row['MONTH']) . "-" . $row['YEAR'];
                                echo "</td>";
                                echo "</tr>";
                            }
                        } 
                        $sql = "SELECT SUM(TAX_AMOUNT) AS Total, EXTRACT(MONTH FROM date) AS MONTH, EXTRACT(YEAR FROM date) AS YEAR FROM billing WHERE year(date) = $y GROUP BY month(date)";

                        $result = $conn->query($sql);
                        $totalExpense2 = 0;
                        if ($result->num_rows > 0) {
                            // output data of each row
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr id='select'><td>";
                                echo "GST";
                                echo "</td>";
                                echo "<td>";
                                echo $row['Total'];
                                $totalExpense2 += $row['Total'];
                                echo "</td>";
                                echo "<td>";
                                echo getMonth($row['MONTH']) . "-" . $row['YEAR'];
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo " Empty";
                        }
                        
                        $conn->close();

                        ?>
                    </table>

                </div>

            </div>
        </div>


    

        <div style="float:right;width: 41%;margin-top: -124px;font-size: 31px;">

            <?php
            echo "<div id='profitloss'>";
            $result = $totalIncome - $totalExpense-$totalExpense2;
            if ($result >= 0) {
                echo "<p id='p1'>";
                echo "Profit = " . $result;
                echo "</p>";
            } else {
                echo "<p id='p2'>";
                echo "Loss =" . -$result;
                echo "</p>";
            }
            echo "</div>";
            ?>

        </div>
        </div>
    <script>
        document.getElementById("p1").style.backgroundColor = "green";
    </script>
    <script>
        document.getElementById("p2").style.backgroundColor = "red";
    </script>

</body>


</html>