<!DOCTYPE html>
<html>

<head>  
    <link href="./css/hotel.css" rel="stylesheet" type="text/css" />
    <link href="./css/all.min.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php

include_once dirname(__FILE__) . './dbDetails.php';
if (isset($_GET['deleteguestid'])) {

    $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

    if ($conn->connect_error) {
        die("connection failed :" . $conn->connect_error);
    }

    $sql = "DELETE FROM guest_details WHERE GUEST_ID = " . $_GET['deleteguestid'];

    if ($conn->query($sql) === TRUE) {
        echo  " deleted succesfully.";
    } else {
        echo "Error deleting name" . $conn->error;
    }
    $conn->close();
}
?>

    <div style="float:center;">


                <table class="tbl">
                    <tr>
                        <th>Guest id</th>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Surname</th>
                        <th>DOB</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Special-Category</th>
                        <th>Country</th>
                        <th>Nationality</th>
                        <th>City</th>
                        <th>Passport No.</th>
                        <th>passport city</th>
                        <th>passport country</th>
                        <th>passport date</th>
                        <th>valid Till</th>
                        <th>Visa No.</th>
                        <th>Visa city</th>
                        <th>Visa country</th>
                        <th>Visa date</th>
                        <th>Valid Till</th>
                        <th>Visa Type</th>
                        <th>Visa Sub Type</th>
                        <th>Arrive Country</th>
                        <th>Arrive City</th>
                        <th>Arrived in India</th>
                        <th>Arrived in Hotel</th>
                        <th>Time_In_Hotel</th>
                        <th>stay-period</th>
                        <th>Employed in India</th>
                        <th>Visit Purpose</th>
                        <th>Next Destination</th>
                        <th>Destination State</th>
                        <th>Destination City</th>
                        <th>Destination Place</th>
                        <th>Contact No. in india</th>
                        <th>Mobile No. in india</th>
                        <th>Contact No. in Country</th>
                        <th>MObile No. in Country</th>
                        <th>Remark</th>
                        <th>Active</th>
                    </tr>
                    <?php
                    include_once dirname(__FILE__) . './dbDetails.php';
                    $conn = new mysqli(dbhost, dbusername, dbpass, dbName);

                    if ($conn->connect_error) {
                        die("connection failed :" . $conn->connect_error);
                    }
                    $sql = "SELECT guest_details.IMAGE,guest_details.GUEST_ID,guest_details.NAME,guest_details.SURNAME,guest_details.GENDER,guest_details.DOB,guest_details.AGE,guest_details.COUNTRY,guest_details.NATIONALITY,guest_details.SPECIAL_CATEGORY,guest_details.VISIT_PURPOSE,cform.CITY,cform.PASSPORT_NO,cform.PASS_CITY,cform.PASS_COUNTRY,cform.PASS_DATE,cform.VALID_DATE,cform.VISA,cform.VISA,cform.VISA_CITY,cform.VISA_COUNTRY,cform.VISA_DATE,cform.VISA_VALID_DATE,cform.VISA_TYPE,cform.VISA_SUBTYPE,cform.ARRIVE_COUNTRY,cform.ARRIVE_COUNTRY,cform.ARRIVE_CITY,cform.DATE_ARRIVE_INDIA,cform.DATE_ARRIVE_HOTEL,cform.TIME_IN_HOTEL,cform.EMPLOYED_IN_INDIA,cform.NEXT_DEST,cform.DEST_STATE,cform.DEST_CITY,cform.DEST_PLACE,cform.CONTACT_INDIA,cform.MOBILE_INDIA,cform.CONTACT_COUNTRY,cform.MOBILE_COUNTRY,cform.REMARK,booking_details.NO_OF_DAYS FROM guest_details,cform,booking_details WHERE guest_details.GUEST_ID=cform.GUEST_ID  AND cform.GUEST_ID = booking_details.GUEST_ID AND COUNTRY != 'INDIA' ORDER BY cform.GUEST_ID DESC ";
                    $result = $conn->query($sql);
                 
                    if ($result->num_rows > 0) {
                        // output data of each row
                        while ($row = $result->fetch_assoc()) {          
                            echo '<tr><td>';
                          
                            echo "<a class='actionicon' href='./bookingdetail.php?guestid=" .$row['GUEST_ID']. "&username=" . $row['NAME'] . "'>";         
                            echo $row['GUEST_ID'];
                            echo "</a>";
                            echo "</td>";
                            echo "<td>";
                            echo "<img src='./images/" .$row['IMAGE'] . "'  height='100px' width='100px'/>";
                            echo "</td>";
                            echo "<td>";
                            echo $row['NAME'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['SURNAME'];
                            echo "</td>";
                            echo "<td>";
                            $newDate = strtotime($row['DOB']);
                            echo date("d-m-y", $newDate);
                            echo "</td>";
                            echo "<td>";
                            echo $row['AGE'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['GENDER'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['SPECIAL_CATEGORY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['COUNTRY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['NATIONALITY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['CITY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['PASSPORT_NO'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['PASS_CITY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['PASS_COUNTRY'];
                            echo "</td>";
                            echo "<td>";
                            $newDate = strtotime($row['PASS_DATE']);
                            echo date("d-m-y", $newDate);
                            echo "</td>";
                            echo "<td>";
                            $newDate = strtotime($row['VALID_DATE']);
                            echo date("d-m-y", $newDate);
                            echo "</td>";
                            echo "<td>";
                            echo $row['VISA'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['VISA_CITY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['VISA_COUNTRY'];
                            echo "</td>";
                            echo "<td>";
                            $newDate = strtotime($row['VISA_DATE']);
                            echo date("d-m-y", $newDate);
                            echo "</td>";
                            echo "<td>";
                            $newDate = strtotime($row['VISA_VALID_DATE']);
                            echo date("d-m-y", $newDate);
                            echo "</td>";
                            echo "<td>";
                            echo $row['VISA_TYPE'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['VISA_SUBTYPE'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['ARRIVE_COUNTRY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['ARRIVE_CITY'];
                            echo "</td>";
                            echo "<td>";
                            $newDate = strtotime($row['DATE_ARRIVE_INDIA']);
                            echo date("d-m-y", $newDate);
                            echo "</td>";
                            echo "<td>";
                            $newDate = strtotime($row['DATE_ARRIVE_HOTEL']);
                        echo date("d-m-y", $newDate);
                            echo "</td>";
                            echo "<td>";
                            echo $row['TIME_IN_HOTEL'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['NO_OF_DAYS'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['EMPLOYED_IN_INDIA'];
                            echo "</td>";
                            echo "<td>"; 
                            echo $row['VISIT_PURPOSE'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['NEXT_DEST'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['DEST_STATE'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['DEST_CITY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['DEST_PLACE'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['CONTACT_INDIA'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['MOBILE_INDIA'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['CONTACT_COUNTRY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['MOBILE_COUNTRY'];
                            echo "</td>";
                            echo "<td>";
                            echo $row['REMARK'];
                            echo "</td>";
                            echo "<td><span style='float: left;'><a class='onicon'  href='./guest.php?guestid=" . $row['GUEST_ID'] . "&username=" . $row['NAME'] . "&age=" . $row['AGE'] . "&DOB=" . $row['DOB'] . "&surname=" . $row['SURNAME'] . "&country=" . $row['COUNTRY'] . "&nationality=" . $row['NATIONALITY'] . "&category=" . $row['SPECIAL_CATEGORY'] . "&gender=" . $row['GENDER'] . "'><i class='fa fa-pencil-alt'></i></a></span>";
                            echo "<span style='float: right;'><a class='actionicon' href='./cform.php?deleteguestid=" . $row['GUEST_ID'] . "'>";
                            echo "<i class='fa fa-trash-alt'></i></a></span></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo " Empty";
                    }
                    $conn->close();

                    ?>
                </table>
            </div>
</body>

</html>